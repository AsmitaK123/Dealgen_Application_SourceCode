﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="SwiftGwListenerServiceInstaller.cs" company="Manulife Financial">
//   Copyright (c) Manulife Financial. All rights reserved.
// </copyright>
// <summary>
//   The service installer.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Mfc.Inv.Swift.DealgenListener
{
    using System;
    using System.ComponentModel;
    using System.Configuration;
    using System.Configuration.Install;
    using System.Diagnostics;
    using System.IO;
    using System.Reflection;
    using System.ServiceProcess;

    /// <summary>
    /// The service installer.
    /// </summary>
    [RunInstaller(true)]
    public class SwiftGwListenerServiceInstaller : Installer
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SwiftGwListenerServiceInstaller"/> class.
        /// </summary>
        public SwiftGwListenerServiceInstaller()
        {

            ServiceProcessInstaller serviceProcessInstaller = new ServiceProcessInstaller();
            ServiceInstaller serviceInstaller = new ServiceInstaller();

            var serviceName = GetAppConfigValue("ServiceName"); 

            //# Service Account Information
            //serviceProcessInstaller.Account = ServiceAccount.User;
            //serviceProcessInstaller.Username = "";
            //serviceProcessInstaller.Password = "";

            //# Service Information
            serviceInstaller.DisplayName = serviceName;
            serviceInstaller.StartType = ServiceStartMode.Automatic;

            // This must be identical to the WindowsService.ServiceBase name
            // set in the constructor of WindowsService.cs
            serviceInstaller.ServiceName = serviceName;

            this.Installers.Add(serviceProcessInstaller);
            this.Installers.Add(serviceInstaller);

        }

        public string GetAppConfigValue(string serviceName)
        {
            var config = ConfigurationManager.OpenExeConfiguration(Assembly.GetAssembly(typeof(SwiftGwListenerServiceInstaller)).Location);
            return config.AppSettings.Settings[serviceName].Value;
        }
    }
}
