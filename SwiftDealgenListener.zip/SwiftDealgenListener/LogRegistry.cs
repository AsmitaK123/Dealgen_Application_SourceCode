﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;
namespace Mfc.Inv.Swift.DealgenListener.Common.Logging
{
    /// <summary>
    /// Load the log4net configuration
    /// </summary>
    public class LogRegistry
    {
        /// <summary>
        /// The _logger.
        /// </summary>
        private ILog _logger;

        /// <summary>
        /// Hold an object of the default ILog of log4net
        /// </summary>
        public ILog Logger
        {
            get { return this._logger; }
            set { this._logger = value; }
        }

        /// <summary>
        /// Hold a list of loggers of log4net
        /// </summary>
        public List<ILog> LoggerList { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="LogRegistry"/> class. 
        /// Load the log4net configuration and initialize it.
        /// </summary>
        /// <param name="loggerName">
        /// </param>
        public LogRegistry(string loggerName)
        {
            log4net.Config.XmlConfigurator.Configure();
            this._logger = LogManager.GetLogger(loggerName);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="LogRegistry"/> class. 
        /// Load the log4net configuration and initialize it.
        /// </summary>
        public LogRegistry()
        {
        }

    }
}
