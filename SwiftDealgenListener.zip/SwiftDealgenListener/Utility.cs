﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Reflection;
using System.Configuration;

namespace Mfc.Inv.Swift.DealgenListener
{
    public class Utility
    {
        private static KeyValueConfigurationCollection configCollection { get; set; }


        public static string GetServiceNameAppConfig(string serviceName)
        {
            if (configCollection == null || configCollection.Count == 0)
            {
                var config = ConfigurationManager.OpenExeConfiguration(Assembly.GetAssembly(typeof(SwiftGwListenerServiceInstaller)).Location);
                configCollection = config.AppSettings.Settings;
            }
            return configCollection[serviceName].Value;
        }
        /// <summary>
        /// Check if string is a valid email address
        /// </summary>
        /// <param name="inputEmail">
        /// Email Address to validate
        /// </param>
        /// <returns>
        /// The <see cref="bool"/>.
        /// </returns>
        public static bool IsValidEmailFormat(string inputEmail)
        {
            const string StrRegex =
                @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" + @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\"
                + @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
            var re = new Regex(StrRegex);
            return re.IsMatch(inputEmail.Trim());
        }
        public static void SendEmail(
            string from,
            string recepients,
            string subject,
            string body)
        {
            var smtp = new SmtpClient();
            string environment = string.Empty;

            var email = new MailMessage { IsBodyHtml = false };

            if (!string.IsNullOrEmpty(from))
            {
                if (IsValidEmailFormat(from))
                {
                    email.From = new MailAddress(from);
                }
                else
                {
                    throw new Exception("From email address format is invalid");
                }
            }

            if (!string.IsNullOrEmpty(recepients))
            {
                string[] aMailTo = recepients.Split(';');
                foreach (var e in aMailTo)
                {
                    if (IsValidEmailFormat(e))
                    {
                        email.To.Add(e);
                    }
                    else
                    {
                        throw new Exception("Receiver's email address format is invalid");
                    }
                }
            }
            else
            {
                throw new Exception("Receiver's email not provided.");
            }

           

            
            email.Subject = subject;
            email.Body = body;

            try
            {
                smtp.Send(email);
            }
            finally
            {
                email.Dispose();
            }
        }
    }
}
