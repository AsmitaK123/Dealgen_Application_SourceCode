﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="JsonContentNegotiator.cs" company="Manulife Financial">
//   Copyright (c) Manulife Financial. All rights reserved.
// </copyright>
// <summary>
//   The json content negotiator.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Mfc.Inv.Swift.DealgenListener
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Net.Http.Formatting;
    using System.Net.Http.Headers;

    using Newtonsoft.Json;

    /// <summary>
    /// The json content negotiator.
    /// </summary>
    public class JsonContentNegotiator : IContentNegotiator
    {
        /// <summary>
        /// json formatter.
        /// </summary>
        private readonly JsonMediaTypeFormatter jsonFormatter;

        /// <summary>
        /// Initializes a new instance of the <see cref="JsonContentNegotiator"/> class.
        /// </summary>
        /// <param name="formatter">
        /// The formatter.
        /// </param>
        public JsonContentNegotiator(JsonMediaTypeFormatter formatter)
        {
            this.jsonFormatter = formatter;
            this.jsonFormatter.SerializerSettings.TypeNameHandling  = TypeNameHandling.Objects;
        }

        /// <summary>
        /// The negotiate.
        /// </summary>
        /// <param name="type">
        /// The type.
        /// </param>
        /// <param name="request">
        /// The request.
        /// </param>
        /// <param name="formatters">
        /// The formatters.
        /// </param>
        /// <returns>
        /// The <see cref="ContentNegotiationResult"/>.
        /// </returns>
        public ContentNegotiationResult Negotiate(Type type, HttpRequestMessage request, IEnumerable<MediaTypeFormatter> formatters)
        {
            var result = new ContentNegotiationResult(this.jsonFormatter, new MediaTypeHeaderValue("application/json"));
            return result;
        }
    }
}
