﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="OnswifteventController.cs" company="Manulife Financial">
//   Copyright (c) Manulife Financial. All rights reserved.
// </copyright>
// <summary>
//   callback service implantation.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Mfc.Inv.Swift.DealgenListener
{
    using System;
    using System.Reflection;
    using System.Configuration;
    using System.Net;
    using System.Web.Http;
    using log4net;
    using Newtonsoft.Json.Serialization;
    using Mfc.Inv.Swift.Common.Messages;
    using Mfc.Inv.Swift.Common.Contracts;
    using Mfc.Inv.Swift.DealgenListener.Common.Logging;
    using System.Linq;
    /// <summary>
    /// callback service implantation.
    /// </summary>
    public class OnswifteventController : ApiController, ISwiftCallbackListener 
    {
        /// <summary>
        /// The logger.
        /// </summary>
        

        private string ServiceEventMailTo;
        private string ServiceEventMailFrom;
        private string DBOEmail;

        private string ServiceName;
        /// <summary>
        /// Initializes a new instance of the <see cref="OnswifteventController"/> class.
        /// </summary>
        public OnswifteventController()
        {
            LogRegistry logRegistry = new LogRegistry("AppLog");
            LogHelper.SetLogger(logRegistry);

            LogHelper.Info("Staring up OnswifteventController");

            this.ServiceEventMailTo = Utility.GetServiceNameAppConfig("ServiceEventMailTo");
            this.ServiceEventMailFrom = Utility.GetServiceNameAppConfig("ServiceEventMailFrom");
            this.ServiceName = Utility.GetServiceNameAppConfig("ServiceName");


            LogHelper.Info("Controller initialized");
        }

        /// <summary>
        /// handle the post.
        /// </summary>
        /// <param name="obj">
        /// The obj.
        /// </param>
        /// <returns>
        /// The <see cref="bool"/>.
        /// </returns>
        public bool Post([FromBody] SwiftEvent obj)
        {
            LogHelper.Info("Post Event");
            LogHelper.Info("Callback swiftEvent received: {0}", Newtonsoft.Json.JsonConvert.SerializeObject(obj));
            string errorMessage = string.Empty;

            string refString = obj.Reference;

            try
            {
                using (var context = new DealgenEntities())
                {

                    var settlement = (from s in context.t_SwiftTransfer
                                      where s.ReferenceString == refString
                                      orderby s.SwiftTransferRecordId descending
                                      select s).FirstOrDefault();

                    if (settlement == null)
                    {
                        throw new Exception("Swift Transfer record not found for Reference String :" + refString);
                    }
                    context.SaveChanges();
                    //ACK / NACK
                    if (obj.EventType == SwiftEventType.SwiftNetworkEvent)
                    {
                        if (settlement.Cancelflag == "Y")
                        {
                            settlement.CancelAckNack = obj.IsAcceptedBySwift.ToString();
                            settlement.CancelAckNackDateTime = DateTime.Now;
                        }
                        else
                        {
                            settlement.ACK_NACK = obj.IsAcceptedBySwift.ToString();
                            settlement.ACK_NACK_DateTime = DateTime.Now;
                        }
                        context.SaveChanges();
                    }
                    else if (obj.EventType == SwiftEventType.CustodialEvent)
                    {
                        settlement.Settled_MsgRcvd = "Y";
                        settlement.Settled_DateTime = DateTime.Now;
                        settlement.CustidialAmount = (decimal)obj.CustodialMessage.Amount;
                        settlement.Settlement_ReferenceString = obj.Reference;
                        settlement.CustodialSwiftOriginal = obj.SwiftMessage;
                        context.SaveChanges();
                    }
                }
            }
            catch (Exception ex)
            {

                errorMessage = string.Format("SwiftEvent error: {0},stack:", ex.Message, ex.StackTrace);
                
                if (ex.InnerException != null)
                {
                    errorMessage += string.Format("SwiftEvent Inner error: {0},stack:", ex.InnerException.Message, ex.InnerException.StackTrace);
                }

                LogHelper.Error(errorMessage);

                string emailTo = GetAppConfigValue("ServiceEventMailTo");
                string emailFrom = GetAppConfigValue("ServiceEventMailFrom");
                Utility.SendEmail(emailFrom, emailTo, "Swift Dealgen Listener failed to process message", errorMessage);

            }
             
            return true;            
        }

        public string GetAppConfigValue(string serviceName)
        {
            var config = ConfigurationManager.OpenExeConfiguration(Assembly.GetAssembly(typeof(SwiftGwListenerServiceInstaller)).Location);
            return config.AppSettings.Settings[serviceName].Value;
        }

        /// <summary>
        /// The get.
        /// </summary>
        public void Get()
        {
            LogHelper.Info("Got a ping");
        }
    }
}
