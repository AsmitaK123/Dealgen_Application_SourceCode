﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;
namespace Mfc.Inv.Swift.DealgenListener.Common.Logging
{
    public static class LogHelper
    {
        /// <summary>
        /// The _log registy.
        /// </summary>
        private static LogRegistry _logRegisty;

        public static void Debug(object message, params object[] args)
        {
            if (message is string && args.Length > 0)
            {
                Logger().DebugFormat((string)message, args);
            }
            else
            {
                Logger().Debug(message);
            }
        }

        public static void Info(object message, params object[] args)
        {
            if (message is string && args.Length > 0)
            {
                Logger().InfoFormat((string)message, args);
            }
            else
            {
                Logger().Info(message);
            }
        }

        public static void Error(object message, params object[] args)
        {
            if (message is string && args.Length > 0)
            {
                Logger().ErrorFormat((string)message, args);
            }
            else
            {
                Logger().Error(message);
            }
        }

        /// <summary>
        /// Utility method to facilitate other methods to get ILog.
        /// </summary>
        /// <returns>
        /// The <see cref="ILog"/>.
        /// </returns>
        private static ILog Logger()
        {
            if (_logRegisty == null)
            {
                throw new Exception("Logger is not set");
            }

            return _logRegisty.Logger;
        }

        /// <summary>
        /// The set logger.
        /// </summary>
        /// <param name="iLogRegisty">
        /// The i log registy.
        /// </param>
        public static void SetLogger(LogRegistry iLogRegisty)
        {
            if (_logRegisty == null)
            {
                _logRegisty = iLogRegisty;
            }
        }

    }
}
