﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="GatewayStartup.cs" company="Manulife Financial">
//   Copyright (c) Manulife Financial. All rights reserved.
// </copyright>
// <summary>
//   The mock gateway startup.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Mfc.Inv.Swift.DealgenListener
{
    using System.Net.Http.Formatting;
    using System.Web.Http;

    using System.Web.Http;
    using System.Web.Http.SelfHost;

    using Autofac.Integration.WebApi;

    /// <summary>
    /// The mock gate way startup.
    /// </summary>
    public class GatewayStartup
    {
        /// <summary>
        /// The configuration.
        /// </summary>
        /// <param name="appBuilder">
        /// The app builder.
        /// </param>
        public void StartWebhost(string url)
        {
            // Configure Web API for self-host. 
            var config = new HttpSelfHostConfiguration(url);
            config.DependencyResolver = new AutofacWebApiDependencyResolver(WindowsServiceWrapper.DiContainer);
            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional });

            var jsonFormater = new JsonMediaTypeFormatter();
            config.Services.Replace(typeof(IContentNegotiator), new JsonContentNegotiator(jsonFormater));

            HttpSelfHostServer server = new HttpSelfHostServer(config);

            server.OpenAsync().Wait();
                        
        }
    }
}
