﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="WindowsServiceWrapper.cs" company="Manulife Financial">
//   Copyright (c) Manulife Financial. All rights reserved.
// </copyright>
// <summary>
//   windows service wrapper for swift gateway listener.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Mfc.Inv.Swift.DealgenListener
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net.Http;
    using System.Reflection;
    using System.ServiceProcess;
    using System.Text;
    using System.Threading;
    using Autofac;
    using Autofac.Integration.WebApi;

    using log4net;
    
    using Mfc.Inv.Swift.Common;
    using Mfc.Inv.Swift.Common.Common;
    using Mfc.Inv.Swift.Common.Messages;
    using System.Configuration;
    
    using Timer = System.Timers.Timer;

    
    /// <summary>
    /// windows service wrapper for swift gateway listener.
    /// </summary>
    public class WindowsServiceWrapper : ServiceBase
    {
        /// <summary>
        /// The di container.
        /// </summary>
        internal static IContainer DiContainer;

        /// <summary>
        /// The getlistenTimer.
        /// </summary>
        private Timer getTimer;

        /// <summary>
        /// The logger.
        /// </summary>
        private static ILog logger =  log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        /// <summary>
        /// The web app.
        /// </summary>
        private IDisposable webApp;

        /// <summary>
        /// The swift gateway registration.
        /// </summary>
        private string swiftSessionGuid;

        private string ServiceEventMailTo;
        private string ServiceEventMailFrom;

        private int timerInterval = 0;

        /// <summary>
        /// The di scope.
        /// </summary>
        private ILifetimeScope diScope;
        
        /// <summary>
        /// Initializes a new instance of the <see cref="WindowsServiceWrapper"/> class.
        /// </summary>
        /// <param name="externalConfig">
        /// The external Config.
        /// </param>
        public WindowsServiceWrapper()
        {


            this.ServiceName = GetAppConfigValue("ServiceName");
            this.ServiceEventMailTo = GetAppConfigValue("ServiceEventMailTo");
            this.ServiceEventMailFrom = GetAppConfigValue("ServiceEventMailFrom");
            this.timerInterval = Convert.ToInt16(GetAppConfigValue("TimerInterval")); 
            this.CallbackUrl = null;

        }

        /// <summary>
        /// The callback url.
        /// </summary>
        public string CallbackUrl { get; private set; }

        /// <summary>
        /// The config.
        /// </summary>

        public string GetAppConfigValue(string serviceName)
        {
            var config = ConfigurationManager.OpenExeConfiguration(Assembly.GetAssembly(typeof(SwiftGwListenerServiceInstaller)).Location);
            return config.AppSettings.Settings[serviceName].Value;
        }

        /// <summary>
        /// public method to start services manually 
        /// </summary>
        public void StartServices()
        {
            logger.InfoFormat("Starting service {0}", this.ServiceName);

            var baseUrl = GetAppConfigValue("serviceUrl");
            CallbackUrl = baseUrl + "/api/Onswiftevent";
            
            //this.RegisterForSwiftCallback();
            this.RegisterDiComponents();

            GatewayStartup gateway = new GatewayStartup();
            gateway.StartWebhost(baseUrl);

            int intervalInSeconds = timerInterval * 60 * 1000;

            if (timerInterval > 0)
            {
                this.getTimer = new Timer(intervalInSeconds);
                this.getTimer.Elapsed += (sender, args) =>
                    {
                        this.getTimer.Enabled = false;
                        this.SelfPing(CallbackUrl);
                    };

                this.getTimer.Start();
            }

        }

        private void SelfPing(string callbackUrl)
        {
            var client = new System.Net.WebClient();
            var content = client.DownloadString(CallbackUrl);
            logger.InfoFormat("MfcSwiftGateway Dealgen Listener Response Content: {0}", content);
            this.getTimer.Enabled = true;
        }

        static void Main()
        {
            ServiceBase.Run(new WindowsServiceWrapper());
        }

        /// <summary>
        /// The on start.
        /// </summary>
        /// <param name="args">
        /// The args.
        /// </param>
        protected override void OnStart(string[] args)
        {
            logger.InfoFormat("Starting service {0}", this.ServiceName);
            base.OnStart(args);
            this.StartServices();
            Utility.SendEmail(
                this.ServiceEventMailTo,
                this.ServiceEventMailFrom,
                this.ServiceName + "-Windows Service Started",
                "No Action Required");

            logger.InfoFormat("service {0} started", this.ServiceName);
        }

        /// <summary>
        /// The on stop.
        /// </summary>
        protected override void OnStop()
        {
            
            logger.InfoFormat("Stopping service {0}", this.ServiceName);
            try
            {
                Utility.SendEmail(
                this.ServiceEventMailTo,
                this.ServiceEventMailFrom,
                this.ServiceName + "-Windows Service Stopped",
                "Escalate to Level II Support");
            }
            catch (Exception ex)
            {
                logger.Error("Service failed to close", ex);
            }
        }

        /// <summary>
        /// register all shared DI components.
        /// </summary>
        private void RegisterDiComponents()
        {
            var diBuilder = new ContainerBuilder();
            
            diBuilder.RegisterApiControllers(Assembly.GetExecutingAssembly());
            diBuilder.RegisterType<GatewayStartup>()
                     .PropertiesAutowired(PropertyWiringOptions.AllowCircularDependencies);
            
            WindowsServiceWrapper.DiContainer = diBuilder.Build();
            this.diScope = 
                WindowsServiceWrapper.DiContainer
                                     .BeginLifetimeScope();
        }

        #region commented
        ///// <summary>
        ///// The register for callback.
        ///// </summary>
        //private void RegisterForSwiftCallback()
        //{
        //    using (var client = new HttpClient())
        //    {
        //        var swiftGwUrl = this.config.GetConfigParam<string>("swiftGatewayRegistrationUrl");
        //        string findurDatabase = this.config.GetConfigParam<string>("AB_LOGON_DATABASE");
        //        string findurDatabaseServer = this.config.GetConfigParam<string>("FindurDatabaseServer");
                
        //        int timeoutInterval = getTimeOutInterval();
        //        string alertEmail = getEmailId();

        //        var registration = new ClientRegistration()
        //                               {
        //                                   CallbackUrl = CallbackUrl, 
        //                                   Type = SwiftClientType.Realtime,
        //                                   ClientName = "FINDUR",
        //                                   AckTimeout = timeoutInterval,
        //                                   AlertEmail = alertEmail,
        //                                   DatabaseName = findurDatabase,
        //                                   DatabaseServer = findurDatabaseServer
        //                               };
                
        //        logger.InfoFormat("Registering with {0}", swiftGwUrl);

        //        try
        //        {
        //            this.swiftSessionGuid =
        //                client.PostAsJsonAsync(swiftGwUrl, registration).Result.Content.ReadAsAsync<string>().Result;

        //            if (string.IsNullOrEmpty(this.swiftSessionGuid))
        //            {
        //                throw new Exception("Unable to register Swift Listener to Swift Gateway, please check whether Swift Gateway services are running");
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            logger.ErrorFormat("Exception occurred :{0}", ex.Message);
        //        }

        //        logger.InfoFormat("Received registration token from Swift Gateway {0}", this.swiftSessionGuid);
        //        logger.InfoFormat("Writing session id to user_script_config table");

        //        this.InsertOrUpdateSessionId();
        //        logger.InfoFormat("session id written into user_script_config table");
        //    }
        //}
        #endregion

        

    }
}
