﻿using System;
using System.IO;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using Excel = Microsoft.Office.Interop.Excel;
using System.Configuration;
using System.Runtime.InteropServices;
namespace DealGenCompliancetoExcel
{
    class Programme
    {
        static void Main(string[] args)
        {
            UtilCls.CBCFUtilities _clsUtil = new UtilCls.CBCFUtilities();
            const string job = "_DealGenCompliancetoExcel";
            const string prefix = "DGEN";
            string BCF_AUTOMATED_JOBEMAIL = ConfigurationManager.AppSettings["bcfmail"];
            string BCF_EMAIL = ConfigurationManager.AppSettings["bcfdatamail"];
            string OutputFilepath = "";
            string JOBNAME = prefix + job + "::";
            string strxlBook = "";
            string fromDate = "";
            string toDate = "";
            Excel.Application xlApp = null;
            Excel.Workbook xlWorkBook = null;
            Excel.Worksheet xlWorkSheet = null;
            if (args.Length != 0)
            {
                fromDate = args[0].ToString();
                toDate = args[1].ToString();
            }
            Console.WriteLine(args.Length);
            Console.WriteLine(fromDate +" "+ toDate);
            DateTime FromDate;
            DateTime ToDate;
            if (fromDate != string.Empty && toDate != string.Empty)
            {
                FromDate = DateTime.ParseExact(fromDate, "MM/dd/yyyy", null);
                ToDate = DateTime.ParseExact(toDate, "MM/dd/yyyy", null);
            }
            else
            {
                FromDate = (DateTime.ParseExact("01/01/2021", "MM/dd/yyyy", null));
                ToDate = DateTime.ParseExact("03/31/2021", "MM/dd/yyyy", null);
            }
            int DateDiff =Convert.ToInt32(((ToDate - FromDate).TotalDays));
            if (DateDiff <= 31)
            {
                OutputFilepath = ConfigurationManager.AppSettings["OutputFilePathMonthly"];
                strxlBook = OutputFilepath + "DealGenCompliance_" + "MonthlyReport_" + FromDate.ToString("MMMyyyy_")+ DateTime.Now.ToString("HHmm") +".xlsx";
            }
            else
            {
                OutputFilepath = ConfigurationManager.AppSettings["OutputFilePathQuarterly"];
                strxlBook = OutputFilepath + "DealGenCompliance_" + "QuarterlyReport_" + FromDate.ToString("MMMyyyy") +"_to_" + ToDate.ToString("MMMyyyy_")+ DateTime.Now.ToString("HHmm")+ ".xlsx";
            }
            try
            {
                Console.WriteLine("Start the task DealGenCompliancetoExcel............");
                Console.WriteLine(ConfigurationManager.ConnectionStrings["dbdgdp1"].ConnectionString);
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbdgdp1"].ConnectionString);
                SqlCommand sqlCommand = new SqlCommand("[dbo].[p_2091_r_compliance_deals_asia]", conn);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.Add(new SqlParameter("@FromDt", SqlDbType.Date)).Value = FromDate;
                sqlCommand.Parameters.Add(new SqlParameter("@ThroughDt", SqlDbType.Date)).Value = ToDate;
                Console.WriteLine("Date Parameters Passed: " + FromDate + ", " + ToDate);
                sqlCommand.CommandTimeout = 60;
                conn.Close();
                conn.Open();
                sqlCommand.Connection.Close();
                sqlCommand.Connection.Open();
                Console.WriteLine("Database Connection Opened Successfully");
                SqlDataReader sqlReader = sqlCommand.ExecuteReader();
                Console.WriteLine("Check Data Count from Database");
                if (sqlReader.HasRows == false)
                {
                    Console.WriteLine("Data Count is zero. So exiting............");

                    Console.WriteLine(JOBNAME + " DGEN_DealGenCompliancetoExcel Job Executed Successfully!");
                    _clsUtil.SendNotificationEmailXP
                          (BCF_AUTOMATED_JOBEMAIL
                           , BCF_EMAIL
                           , JOBNAME + " ALERT - DGEN_DealGenCompliancetoExcel Job Notification EMail - There is no Data to Import"
                           , "DGEN_DealGenCompliancetoExcel Job Executed Successfully!. "
                              + " There is no Data to Import "
                              + " "
                           , "", "", "");
                }
                else
                {
                    string SQL;
                    strxlBook = strxlBook.Replace("/", "_");
                    object misValue = System.Reflection.Missing.Value;
                    xlApp = new Excel.Application();
                    xlWorkBook = xlApp.Workbooks.Add(misValue);
                    xlWorkSheet = xlWorkBook.Worksheets[1];
                    xlWorkSheet.Select(Type.Missing);
                    xlWorkSheet.Range["1:1"].Font.Bold = true;
                    xlWorkSheet.Range["A:A"].NumberFormat = "mm/dd/yyyy";
                    xlWorkSheet.Cells[1, 1] = "Date";
                    xlWorkSheet.Cells[1, 2] = "Time";
                    xlWorkSheet.Range["B:B"].NumberFormat = "hh:mm:ms";
                    xlWorkSheet.Cells[1, 3] = "Investment Id";
                    xlWorkSheet.Cells[1, 4] = "Event";
                    xlWorkSheet.Cells[1, 5] = "Who First Name";
                    xlWorkSheet.Cells[1, 6] = "Who Last Name";
                    xlWorkSheet.Range["G:G"].NumberFormat = "@";
                    xlWorkSheet.Cells[1, 7] = "InvestmentCd / CUSIP";
                    xlWorkSheet.Cells[1, 8] = "Issuer Name";
                    xlWorkSheet.Range["I:I"].NumberFormat = "mm/dd/yyyy";
                    xlWorkSheet.Cells[1, 9] = "Issuer Date";
                    xlWorkSheet.Cells[1, 10] = "Moodys Rating";
                    xlWorkSheet.Cells[1, 11] = "S&P Rating";
                    xlWorkSheet.Cells[1, 12] = "JHRating";
                    xlWorkSheet.Cells[1, 13] = "Asset Category";
                    xlWorkSheet.Cells[1, 14] = "Transaction Type";
                    xlWorkSheet.Cells[1, 15] = "Deal Id";
                    xlWorkSheet.Cells[1, 16] = "TransactionComment";
                    xlWorkSheet.Cells[1, 17] = "Broker Name";
                    xlWorkSheet.Cells[1, 18] = "Legal Desc";
                    xlWorkSheet.Cells[1, 19] = "SubAccountCode";
                    xlWorkSheet.Cells[1, 20] = "Funding Amount";
                    xlWorkSheet.Range["U:U"].NumberFormat = "mm/dd/yyyy";
                    xlWorkSheet.Cells[1, 21] = "SettlementDt";
                    xlWorkSheet.Cells[1, 22] = "DP Approve";
                    xlWorkSheet.Cells[1, 23] = "WireTransferApprove";
                    xlWorkSheet.Cells[1, 24] = "Cancel Transaction Reason";
                    xlWorkSheet.Cells[1, 25] = "Reject Transaction Reason";
                    Console.WriteLine("Getting Data from Databse");
                    SQL = "[dbo].[p_2091_r_compliance_deals_asia]";
                    conn.Close();
                    SqlCommand cmdadapter = new SqlCommand(SQL);
                    cmdadapter.CommandTimeout = 60;
                    cmdadapter.Connection = conn;
                    cmdadapter.CommandType = CommandType.StoredProcedure;
                    cmdadapter.Parameters.Add(new SqlParameter("@FromDt", SqlDbType.Date)).Value = FromDate;
                    cmdadapter.Parameters.Add(new SqlParameter("@ThroughDt", SqlDbType.Date)).Value = ToDate;
                    SqlDataAdapter dscmd = new SqlDataAdapter(cmdadapter);
                    DataSet ds = new DataSet();
                    dscmd.Fill(ds);
                    for (var i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                    {
                        for (var j = 0; j <= ds.Tables[0].Columns.Count - 1; j++)
                            xlWorkSheet.Cells[i + 2, j + 1] = ds.Tables[0].Rows[i][j].ToString();
                    }
                    Console.WriteLine("Data Inserted Into Excel Sheet");

                    xlWorkSheet.SaveAs(@strxlBook);
                    xlWorkBook.Close();
                    
                    conn.Close();
                    Console.WriteLine("Data loaded successfully from database table to Excel sheet");
                    _clsUtil.SendNotificationEmailXP
                             (BCF_AUTOMATED_JOBEMAIL
                              , BCF_EMAIL
                              , JOBNAME + "Success - DealGenCompliancetoExcel Job Executed Successfully"
                              , "DealGen Compliance report data has been successfully Imported at:" + strxlBook
                              , "", "", "");
                    Console.WriteLine("Notifications Sent Successfully");
                }
            }
            catch (Exception ex)
            {
                _clsUtil.SendNotificationEmailXP
                (BCF_AUTOMATED_JOBEMAIL
                , BCF_EMAIL
                , "Job " + strxlBook + " DealGenCompliancetoExcel"
                , "The error is " + ex.Message
                , "", "", "");
                xlWorkBook.Close();
                xlApp.Quit();
            }
        }
    }
}
