﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SharePoint.Client;
using System.IO;
using System.Web;
using System.Net.Http;
using System.Security;


namespace FileToSharePoint
{
    class FilesToSharepointchecks
    {
        public bool folderExist(ClientContext ctx, Web myweb, string LibraryName,object fcInfo)
        {
            //Folder folder = myweb.GetFolderByServerRelativeUrl(LibraryName);
            //ctx.Load(folder);
            //ctx.ExecuteQuery();

            Folder myLibrary = myweb.GetFolderByServerRelativeUrl(LibraryName);
            ctx.Load(myLibrary);
           
            if (myLibrary.Folders.Count > 0)
            {
                
                ctx.ExecuteQuery();
                return true;
            }
            else
            {
                return false;
            }
            
        }
    }
}
