﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileToSharePoint
{
    class Class1
    {

        using (CSOM.ClientContext clientContext = new CSOM.ClientContext(SPserverUrl))
                {
      clientContext.Credentials = new System.Net.NetworkCredential(Username, Password, Domain);
                    CSOM.Web _Site = clientContext.Web;
                   // string listrootfolder = "Testlist";
                    CSOM.List _List = _Site.Lists.GetByTitle("Testlist");
                    clientContext.Load(_List.RootFolder);
                    clientContext.ExecuteQuery();
                    string listrootfolder = _List.RootFolder.Name.ToString();
    var folder = CreateFolder(clientContext.Web, "Testlist", folderpath);

                        // uploading the document
                        CSOM.FileCreationInformation newFile = new CSOM.FileCreationInformation();
                        // newFile.Content = System.IO.File.ReadAllBytes(@"D:\Testupload.docx");  
                        byte[] bytes = Convert.FromBase64String(objReqDocumentDetials.FileData.ToString());
                        newFile.Content = bytes;
                        //   newFile.Url = objDocumentDetials.AttachmentName.ToString() + DateTime.Now.ToString("ddMMyyyyHHmmsss") + "." +          objDocumentDetials.FileType.ToString();
                        newFile.Url = objReqDocumentDetials.FileName.ToString() + "." + objReqDocumentDetials.FileType.ToString();
                        newFile.Overwrite = true;
                        Microsoft.SharePoint.Client.File _UploadingFile = folder.Files.Add(newFile);

                        var item = _UploadingFile.ListItemAllFields;
                        // var folder = item.GetFolder("account/" + folderName);
                      //  item["Year"] = DateTime.Now.Year.ToString();
                    //    item.Update();

                        clientContext.Load(_UploadingFile, f => f.ListItemAllFields);
                        clientContext.ExecuteQuery();
    }

    public CSOM.Folder CreateFolder(CSOM.Web web, string listTitle, string fullFolderPath)
    {
        if (string.IsNullOrEmpty(fullFolderPath))
            throw new ArgumentNullException("fullFolderPath");
        CSOM.List list = web.Lists.GetByTitle(listTitle);
        return CreateFolderInternal(web, list.RootFolder, fullFolderPath);
    }

    public CSOM.Folder CreateFolderInternal(CSOM.Web web, CSOM.Folder parentFolder, string fullFolderPath)
    {
        var folderUrls = fullFolderPath.Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
        string folderUrl = folderUrls[0];
        var curFolder = parentFolder.Folders.Add(folderUrl);
        web.Context.Load(curFolder);
        web.Context.ExecuteQuery();

        if (folderUrls.Length > 1)
        {
            var folderPath = string.Join("/", folderUrls, 1, folderUrls.Length - 1);
            return CreateFolderInternal(web, curFolder, folderPath);
        }
        return curFolder;
    }


    }
}
