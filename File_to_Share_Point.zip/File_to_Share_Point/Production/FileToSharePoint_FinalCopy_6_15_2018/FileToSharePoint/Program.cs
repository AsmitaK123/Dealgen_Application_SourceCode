﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SharePoint.Client;
using System.IO;
using System.Web;
using System.Net.Http;
using System.Security;
using FileToSharePoint;
using System.Configuration;



namespace FileToSharePoint
{
    public class Program
    {
        public static void Main(string[] args)
        {
            UtilCls.CBCFUtilities _Util = new UtilCls.CBCFUtilities();
            string Mailfrom = ConfigurationManager.AppSettings["bcfmailfrom"];
            string Mailto = ConfigurationManager.AppSettings["bcfmailto"];

            string fileToUpload = args[0]; 
            //string fileToUpload = @"C:\test.pdf";
            Console.WriteLine("Parameter value is : {0}", fileToUpload);

            //string LibraryName = "https://mfc.sharepoint.com/sites/trading/TradingInfo/BCFG Blotter/test.pdf";
            string LibraryName = args[1];
            //string sharePointSite = "https://mfc.sharepoint.com/sites/testGF/";
             
            string filename = fileToUpload.Substring(fileToUpload.LastIndexOf("\\") + 1);
            
            string str1 = LibraryName.Substring(LibraryName.LastIndexOf("/")+1);
            //string str2 = "https://mfc.sharepoint.com/sites/testGF/Shared Documents";

   
            string chkrootfolder = LibraryName.Replace(str1, "");
            
            //BCF Blotter
            if (chkrootfolder.IndexOf("Trade Tickets") != -1)
            {
                try
                {
                    string sharePointSite = ConfigurationManager.AppSettings["sharePointSite"];
                    string str2 = ConfigurationManager.AppSettings["tradeticketBasepath"];
                    string lib = LibraryName.Replace(str1, "");
                    string Librarychk = lib.Replace(str2, "");

                    using (ClientContext ctx = new ClientContext(sharePointSite))
                    {
                        string pwd = ConfigurationManager.AppSettings["Password"];
                        string userId = ConfigurationManager.AppSettings["UserId"];
                        string passwordPre = pwd;
                        char[] passwordChars = passwordPre.ToCharArray();
                        SecureString password = new SecureString();
                        foreach (char c in passwordChars)
                        {
                            password.AppendChar(c);
                        }
                        var creds = new SharePointOnlineCredentials(userId, password);
                        ctx.Credentials = creds;
                        Web myweb = ctx.Web;

                        //--------------------- Check The folder present or not if not present then create ----------------------//

                        var folder = CreateFolder(myweb, "Trade Tickets", Librarychk);

                        //---------------------- Upload to root folder --------------------------- //

                        FileCreationInformation fcInfo = new FileCreationInformation();

                        fcInfo.Url = LibraryName;
                        fcInfo.Overwrite = true;
                        fcInfo.Content = System.IO.File.ReadAllBytes(fileToUpload);
                        List myLibrary = myweb.Lists.GetByTitle("Trade Tickets");
                        myLibrary.RootFolder.Files.Add(fcInfo);
                        ctx.Load(myLibrary);
                        System.Net.ServicePointManager.SecurityProtocol |= System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                        ctx.ExecuteQuery();

                        Console.WriteLine("Files has been loaded Successfully to Sharepoint site!!");
                        Environment.Exit(0);
                    }
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.Message);
                    string errormsg = string.Empty;

                    errormsg = string.Format("FileTosharepoint Message error: {0},{1}:", ex.Message, ex.StackTrace);

                    if (ex.InnerException != null)
                    {
                        errormsg += string.Format("FileTosharepoint Inner error: {0},{1}", ex.InnerException.Message, ex.InnerException.StackTrace);
                    }

                    _Util.SendNotificationEmailXP(Mailfrom, Mailto, "Failed Notification .", "Error is : '" + errormsg + "'", "", "", "");
                    //Console.ReadLine();
                    //throw;
                }
            }
            
            //JHID Feed
            else if (chkrootfolder.IndexOf("Summary Reports") != -1)
            {
                try
                {
                    string sharePointSite = ConfigurationManager.AppSettings["sharePointSite"];
                    string str2 = ConfigurationManager.AppSettings["summaryblotterBasepath"];
                    string lib = LibraryName.Replace(str1, "");
                    string Librarychk = lib.Replace(str2, "");
                    using (ClientContext ctx = new ClientContext(sharePointSite))
                    {
                        string pwd = ConfigurationManager.AppSettings["Password"];
                        string userId = ConfigurationManager.AppSettings["UserId"];
                        string passwordPre = pwd;
                        char[] passwordChars = passwordPre.ToCharArray();
                        SecureString password = new SecureString();
                        foreach (char c in passwordChars)
                        {
                            password.AppendChar(c);
                        }
                        var creds = new SharePointOnlineCredentials(userId, password);
                        ctx.Credentials = creds;
                        Web myweb = ctx.Web;

                        //--------------------- Check The folder present or not if not present then create ----------------------//

                        var folder = CreateFolder(myweb, "Summary Reports", Librarychk);

                        //---------------------- Upload to root folder --------------------------- //

                        FileCreationInformation fcInfo = new FileCreationInformation();

                        fcInfo.Url = LibraryName;
                        fcInfo.Overwrite = true;
                        fcInfo.Content = System.IO.File.ReadAllBytes(fileToUpload);
                        List myLibrary = myweb.Lists.GetByTitle("Summary Reports");
                        myLibrary.RootFolder.Files.Add(fcInfo);
                        ctx.Load(myLibrary);
                        System.Net.ServicePointManager.SecurityProtocol |= System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;

                        ctx.ExecuteQuery();

                        Console.WriteLine("Files has been loaded Successfully to Sharepoint site!!");
                        Environment.Exit(0);
                    }
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.Message);
                    string errormsg = string.Empty;

                    errormsg = string.Format("FileTosharepoint Message error: {0},{1}:", ex.Message, ex.StackTrace);

                    if (ex.InnerException != null)
                    {
                        errormsg += string.Format("FileTosharepoint Inner error: {0},{1}", ex.InnerException.Message, ex.InnerException.StackTrace);
                    }

                    _Util.SendNotificationEmailXP(Mailfrom, Mailto, "Failed Notification .", "Error is : '" + errormsg + "'", "", "", "");
                    //Console.ReadLine();
                    //throw;
                }

            }
            
            //Trading Info
            else if (chkrootfolder.IndexOf("BCFG Blotter") != -1)
            {
                try
                {
                    string sharePointSite = ConfigurationManager.AppSettings["sharePointSite"];
                    string str2 = ConfigurationManager.AppSettings["bcfgBoltterBasepath"];
                    string lib = LibraryName.Replace(str1, "");
                    string Librarychk = lib.Replace(str2, "");
                    using (ClientContext ctx = new ClientContext(sharePointSite))
                    {
                        string pwd = ConfigurationManager.AppSettings["Password"];
                        string userId = ConfigurationManager.AppSettings["UserId"];
                        string passwordPre = pwd;
                        char[] passwordChars = passwordPre.ToCharArray();
                        SecureString password = new SecureString();
                        foreach (char c in passwordChars)
                        {
                            password.AppendChar(c);
                        }
                        var creds = new SharePointOnlineCredentials(userId, password);
                        ctx.Credentials = creds;
                        Web myweb = ctx.Web;

                        //--------------------- Check The folder present or not if not present then create ----------------------//

                        if ((Librarychk != "/"))
                        {
                            var folder = CreateFolder(myweb, "BCFG Blotter", Librarychk);
                        }

                        //---------------------- Upload to root folder --------------------------- //

                        FileCreationInformation fcInfo = new FileCreationInformation();

                        fcInfo.Url = LibraryName;
                        fcInfo.Overwrite = true;
                        fcInfo.Content = System.IO.File.ReadAllBytes(fileToUpload);
                        List myLibrary = myweb.Lists.GetByTitle("BCFG Blotter");
                        myLibrary.RootFolder.Files.Add(fcInfo);
                        ctx.Load(myLibrary);
                        System.Net.ServicePointManager.SecurityProtocol |= System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                        ctx.ExecuteQuery();

                        Console.WriteLine("Files has been loaded Successfully to Sharepoint site!!");
                        Environment.Exit(0);
                    }
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.Message);
                    string errormsg = string.Empty;

                    errormsg = string.Format("FileTosharepoint Message error: {0},{1}:", ex.Message, ex.StackTrace);

                    if (ex.InnerException != null)
                    {
                        errormsg += string.Format("FileTosharepoint Inner error: {0},{1}", ex.InnerException.Message, ex.InnerException.StackTrace);
                    }

                    _Util.SendNotificationEmailXP(Mailfrom, Mailto, "Failed Notification .", "Error is : '" + errormsg + "'", "", "", "");
                    //Console.ReadLine();
                    //throw;
                }
            }


            else if (chkrootfolder.IndexOf("HCIM Blotter") != -1)
            {
                try
                {

                    string sharePointSite = ConfigurationManager.AppSettings["sharePointSite"];
                    string str2 = ConfigurationManager.AppSettings["hcimBoltterBasepath"];
                    string lib = LibraryName.Replace(str1, "");
                    string Librarychk = lib.Replace(str2, "");

                    using (ClientContext ctx = new ClientContext(sharePointSite))
                    {
                        string pwd = ConfigurationManager.AppSettings["Password"];
                        string userId = ConfigurationManager.AppSettings["UserId"];
                        string passwordPre = pwd;
                        char[] passwordChars = passwordPre.ToCharArray();
                        SecureString password = new SecureString();
                        foreach (char c in passwordChars)
                        {
                            password.AppendChar(c);
                        }
                        var creds = new SharePointOnlineCredentials(userId, password);
                        ctx.Credentials = creds;
                        Web myweb = ctx.Web;

                        //--------------------- Check The folder present or not if not present then create ----------------------//

                        if ((Librarychk != "/"))
                        {
                            var folder = CreateFolder(myweb, "HCIM Blotter", Librarychk);
                        }
                        
                        //---------------------- Upload to root folder --------------------------- //

                        FileCreationInformation fcInfo = new FileCreationInformation();

                        fcInfo.Url = LibraryName;
                        fcInfo.Overwrite = true;
                        fcInfo.Content = System.IO.File.ReadAllBytes(fileToUpload);
                        List myLibrary = myweb.Lists.GetByTitle("HCIM Blotter");
                        myLibrary.RootFolder.Files.Add(fcInfo);
                        ctx.Load(myLibrary);
                        System.Net.ServicePointManager.SecurityProtocol |= System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                        ctx.ExecuteQuery();

                        Console.WriteLine("Files has been loaded Successfully to Sharepoint site!!");
                        Environment.Exit(0);
                    }
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.Message);
                    string errormsg = string.Empty;

                    errormsg = string.Format("FileTosharepoint Message error: {0},{1}:", ex.Message, ex.StackTrace);

                    if (ex.InnerException != null)
                    {
                        errormsg += string.Format("FileTosharepoint Inner error: {0},{1}", ex.InnerException.Message, ex.InnerException.StackTrace);
                    }

                    _Util.SendNotificationEmailXP(Mailfrom, Mailto, "Failed Notification .", "Error is : '" + errormsg + "'", "", "", "");
                    //Console.ReadLine();
                    //throw;
                }
            }

            else if (chkrootfolder.IndexOf("JHID Blotter") != -1)
            {
                try
                {
                    string sharePointSite = ConfigurationManager.AppSettings["sharePointSite"];
                    string str2 = ConfigurationManager.AppSettings["jhidBoltterBasepath"];
                    string lib = LibraryName.Replace(str1, "");
                    string Librarychk = lib.Replace(str2, "");

                    using (ClientContext ctx = new ClientContext(sharePointSite))
                    {
                        string pwd = ConfigurationManager.AppSettings["Password"];
                        string userId = ConfigurationManager.AppSettings["UserId"];
                        string passwordPre = pwd;
                        char[] passwordChars = passwordPre.ToCharArray();
                        SecureString password = new SecureString();
                        foreach (char c in passwordChars)
                        {
                            password.AppendChar(c);
                        }
                        var creds = new SharePointOnlineCredentials(userId, password);
                        ctx.Credentials = creds;
                        Web myweb = ctx.Web;

                        //--------------------- Check The folder present or not if not present then create ----------------------//

                        if ((Librarychk != "/"))
                        {
                            var folder = CreateFolder(myweb, "JHID Blotter", Librarychk);
                        }

                        //---------------------- Upload to root folder --------------------------- //

                        FileCreationInformation fcInfo = new FileCreationInformation();

                        fcInfo.Url = LibraryName;
                        fcInfo.Overwrite = true;
                        fcInfo.Content = System.IO.File.ReadAllBytes(fileToUpload);
                        List myLibrary = myweb.Lists.GetByTitle("JHID Blotter");
                        myLibrary.RootFolder.Files.Add(fcInfo);
                        ctx.Load(myLibrary);
                        System.Net.ServicePointManager.SecurityProtocol |= System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
                        ctx.ExecuteQuery();

                        Console.WriteLine("Files has been loaded Successfully to Sharepoint site!!");
                        Environment.Exit(0);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    string errormsg = string.Empty;

                    errormsg = string.Format("FileTosharepoint Message error: {0},{1}:", ex.Message, ex.StackTrace);

                    if (ex.InnerException != null)
                    {
                        errormsg += string.Format("FileTosharepoint Inner error: {0},{1}", ex.InnerException.Message, ex.InnerException.StackTrace);
                    }

                    _Util.SendNotificationEmailXP(Mailfrom, Mailto, "Failed Notification .", "Error is : '" + errormsg + "'", "", "", "");
                    //Console.ReadLine();
                    //throw;
                }
            }
        
        
        }

        public static Folder CreateFolder(Web web, string listTitle, string fullFolderPath)
        {
            if (string.IsNullOrEmpty(fullFolderPath))
                throw new ArgumentNullException("fullFolderPath");
            List list = web.Lists.GetByTitle(listTitle);
            return CreateFolderInternal(web, list.RootFolder, fullFolderPath);
        }
        public static Folder CreateFolderInternal(Web web, Folder parentFolder, string fullFolderUrl)
        {
            var folderUrls = fullFolderUrl.Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
            
            string folderUrl = folderUrls[0];
            
            var curFolder = parentFolder.Folders.Add(folderUrl);
            Microsoft.SharePoint.Client.ListItem item = curFolder.ListItemAllFields;
            //put field names in config
            //string id = "";
            web.Context.Load(item);
            System.Net.ServicePointManager.SecurityProtocol |= System.Net.SecurityProtocolType.Tls11 | System.Net.SecurityProtocolType.Tls12;
            web.Context.ExecuteQuery();
            
            
            //ctx.ExecuteQuery();
            try
            {

                web.Context.Load(curFolder);
                web.Context.ExecuteQuery();

                if (folderUrls.Length > 1)
                {
                    var subFolderUrl = string.Join("/", folderUrls, 1, folderUrls.Length - 1);
                    return CreateFolderInternal(web, curFolder, subFolderUrl);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Upload Failed",ex.Message);
            }
            return curFolder;
        }

                
       
    }

  
}
