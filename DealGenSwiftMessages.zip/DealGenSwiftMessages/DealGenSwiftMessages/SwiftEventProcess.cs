﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.Web;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;
using Mfc.Inv.Swift.Common;
using Mfc.Inv.Swift.Common.Contracts;
using Mfc.Inv.Swift.Common.Messages;
using System.Web.Script.Serialization;
using System.Text;
using System.Net.Http;
using System.Net;
using System.Data;
using System.Data.SqlClient;
using System.Runtime.Serialization;


namespace DealGenSwiftMessages
{
    class SwiftEventProcess 
    {
        //------------------------ Declaring All the required fields for Wire Transfer Instrunction ------------------
        
        int SwiftTransferRecordId;
        decimal dealId;
        decimal investmentId;
        decimal fundingActualId;
        decimal transactionId;
        decimal transactionBreakdownId;
        decimal issuerId;
        string investmentCd;
        string investmentDescription;
        decimal legalEntityId;
        string session_Id;
        double amount;
        string currency;
        DateTime eventDate;
        string username;
        string referenceString;
        string internal_First_Intermediary_Name;
        string internal_First_Intermediary_Account_Number;
        string internal_First_Intermediary_BIC_Code;
        string internal_First_Intermediary_Address;
        string internal_First_Intermediary_IsFi;
        string internal_First_Intermediary_Delivery_Code;
        //Including Internal Secondary Intermediary
        string Internal_Second_Intermediary_Name;
        string Internal_Second_Intermediary_Account_Number;
        string Internal_Second_Intermediary_BIC_Code;
        string Internal_Second_Intermediary_Address;
        string Internal_Second_Intermediary_IsFI;
        string Internal_Second_Intermediary_Delivery_Code;
        string internal_Final_Beneficiary_Name;
        string internal_Final_Beneficiary_Account_Number;
        string internal_Final_Beneficiary_BIC_Code;
        string internal_Final_Beneficiary_Address;
        string internal_Final_Beneficiary_IsFi;
        string internal_Final_Beneficiary_Delivery_Code;
        //Including Internal Ordering Institution
        string Internal_Ordering_Institution_Name;
        string Internal_Ordering_Institution_Account_Number;
        string Internal_Ordering_Institution_BIC_Code;
        string Internal_Ordering_Institution_Address;
        string Internal_Ordering_Institution_IsFI;
        string Internal_Ordering_Institution_Delivery_Code;
        // Including First Intermediary
        string External_First_Intermediary_Name;
        string External_First_Intermediary_Account_Number;
        string External_First_Intermediary_BIC_Code;
        string External_First_Intermediary_Address;
        string External_First_Intermediary_IsFI;
        string External_First_Intermediary_Delivery_Code;
        // Including Second Intermediary
        string External_Second_Intermediary_Name;
        string External_Second_Intermediary_Account_Number;
        string External_Second_Intermediary_BIC_Code;
        string External_Second_Intermediary_Address;
        string External_Second_Intermediary_IsFI;
        string External_Second_Intermediary_Delivery_Code;
        string external_Final_Beneficiary_Name;
        string external_Final_Beneficiary_Account_Number;
        string external_Final_Beneficiary_BIC_Code;
        string external_Final_Beneficiary_Address;
        string external_Final_Beneficiary_IsFi;
        string external_Final_Beneficiary_Delivery_Code;
        //Including Ordering Institutution
        string External_Ordering_Institution_Name;
        string External_Ordering_Institution_Account_Number;
        string External_Ordering_Institution_BIC_Code;
        string External_Ordering_Institution_Address;
        string External_Ordering_Institution_IsFI;
        string External_Ordering_Institution_Delivery_Code;

        string send_Flag;
        //DateTime EntryDateTime;
        //DateTime SentDateTime;
        string ackNack;
        //DateTime ACK_NACK_DateTime;
        string settledMsgrcvd;
        DateTime Settled_DateTime;
        string settlementReferenceString;
        double custodialAmount;
        string custodialSwiftOriginal;
        string swiftMessage;
        string cancelflag;
        DateTime cancelDatetime;
        string cancelAckNack;
        DateTime cancelAckNackDatetime;
        int approverId;
        string approveFlag;
        string reviewFlag;
        DateTime approveDatetime;
         
        public static bool Init()
        {
            //GetFullPath
            Console.WriteLine("Getting Config file");
            ExeConfigurationFileMap configFileMap = new ExeConfigurationFileMap(); //Configpath
            configFileMap.ExeConfigFilename = Path.GetFullPath(@"E:\Dealgen\ESP\Swift\bcfconfig.cfg");   //("""","")) + " \bcfconfig.cfg "));
            Configuration config = ConfigurationManager.OpenMappedExeConfiguration(configFileMap, ConfigurationUserLevel.None);
            ConnectionStringsSection appsetting = (ConnectionStringsSection)config.GetSection("connectionStrings");
            
            string connection = ConfigurationManager.ConnectionStrings["DealGenSwiftMessages.Properties.Settings.dbDGDp1ConnectionString"].ConnectionString;
            //string connection = appsetting.ConnectionStrings["DealGenSwiftMessages.Properties.Settings.dbDGDp1ConnectionString"].ConnectionString;
           
            
            string YesFlag = "Y";
            string NoFlag = "N";

            using (SwiftMessagesDataContext sd = new SwiftMessagesDataContext(connection))
            {
                
                var recordinit = (from i in sd.t_SwiftTransfers
                                  where i.session_ID == null &&  (i.Cancelflag == null || i.Cancelflag == NoFlag) && i.ApproveFlag == YesFlag && i.ReviewFlag == YesFlag && i.Settled_MsgRcvd == null && i.Send_Flag == YesFlag
                                  select i).FirstOrDefault();
               
                //var count = sd.t_SwiftTransfers.Count(recordinit => recordinit.session_ID == this  )
                ///var count = recordinit.count();
                if (recordinit != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }


            }
            
        }
        public static bool InitCancel()
        {
            
            Console.WriteLine("Getting Config file");
            ExeConfigurationFileMap configFileMap = new ExeConfigurationFileMap();
            configFileMap.ExeConfigFilename = Path.GetFullPath(@"E:\Dealgen\ESP\Swift\bcfconfig.cfg");
            Configuration config = ConfigurationManager.OpenMappedExeConfiguration(configFileMap, ConfigurationUserLevel.None);
            ConnectionStringsSection appsetting = (ConnectionStringsSection)config.GetSection("connectionStrings");
            //string connection = appsetting.ConnectionStrings["DealGenSwiftMessages.Properties.Settings.dbDGDp1ConnectionString"].ConnectionString;
            string connection = ConfigurationManager.ConnectionStrings["DealGenSwiftMessages.Properties.Settings.dbDGDp1ConnectionString"].ConnectionString;
            string YesFlag = "Y";

            using (SwiftMessagesDataContext sdc = new SwiftMessagesDataContext(connection))
            {

                var recordcancel = (from i in sdc.t_SwiftTransfers
                                    where i.session_ID != null && i.ReferenceString != null && i.Cancelflag == YesFlag && i.CancelDateTime == null && i.Settled_MsgRcvd == null
                                    select i).FirstOrDefault();

                if (recordcancel != null)
                {
                    return true;
                }

                else
                {
                    return false;   
                }
                
            }

        }
        public void InitDataMember()
        {
            ExeConfigurationFileMap configFileMap = new ExeConfigurationFileMap();
            configFileMap.ExeConfigFilename = Path.GetFullPath(@"E:\Dealgen\ESP\Swift\bcfconfig.cfg");
            Configuration config = ConfigurationManager.OpenMappedExeConfiguration(configFileMap, ConfigurationUserLevel.None);
            ConnectionStringsSection appsetting = (ConnectionStringsSection)config.GetSection("connectionStrings");
            string connection = ConfigurationManager.ConnectionStrings["DealGenSwiftMessages.Properties.Settings.dbDGDp1ConnectionString"].ConnectionString;

            using (SwiftMessagesDataContext sd1 = new SwiftMessagesDataContext(connection))
            {

                string YesFlag = "Y";
                string NoFlag = "N";

                var record2 = (from i in sd1.t_SwiftTransfers
                               where i.session_ID == null && (i.Cancelflag == null || i.Cancelflag == NoFlag) && i.ApproveFlag == YesFlag && i.ReviewFlag == YesFlag && i.Settled_MsgRcvd == null && i.Send_Flag == YesFlag
                               select i).FirstOrDefault();


                if (record2 != null)
                {
                    SwiftTransferRecordId = record2.SwiftTransferRecordId;
                    dealId = (record2.DealId);
                    investmentId = record2.InvestmentId;
                    fundingActualId = record2.FundingActualId;
                    transactionId = record2.TransactionId;
                    transactionBreakdownId = record2.TransactionBreakdownId;
                    if (record2.IssuerId == null)
                    {
                        issuerId = 0;
                    }
                    else
                    {
                        issuerId = (decimal)record2.IssuerId;
                    }
                    investmentCd = record2.InvestmentCd;
                    investmentDescription = record2.InvestmentDescription;
                    if (record2.LegalEntityId == null)
                    {
                        legalEntityId = 0;
                    }
                    else
                    {
                        legalEntityId = (decimal)record2.LegalEntityId;
                    }
                 
                    if (record2.Amount == null)
                    {
                        amount = 0;
                    }
                    else
                    {
                        amount = double.Parse(record2.Amount.ToString());
                    }
                    currency = record2.Currency;
                    
                    eventDate = Convert.ToDateTime(record2.EventDate, System.Globalization.CultureInfo.GetCultureInfo("hi-IN").DateTimeFormat);
                    username = record2.Username;
                    referenceString = record2.ReferenceString;
                    internal_First_Intermediary_Name = record2.Internal_First_Intermediary_Name;
                    internal_First_Intermediary_Account_Number = record2.Internal_First_Intermediary_Account_Number;
                    internal_First_Intermediary_BIC_Code = record2.Internal_First_Intermediary_BIC_Code;
                    internal_First_Intermediary_Address = record2.Internal_First_Intermediary_Address;
                    internal_First_Intermediary_IsFi = record2.Internal_First_Intermediary_IsFI;
                    internal_First_Intermediary_Delivery_Code = record2.Internal_First_Intermediary_Delivery_Code;
                    Internal_Second_Intermediary_Name = record2.Internal_Second_Intermediary_Name;
                    Internal_Second_Intermediary_Account_Number = record2.Internal_Second_Intermediary_Account_Number;
                    Internal_Second_Intermediary_BIC_Code = record2.Internal_Second_Intermediary_BIC_Code;
                    Internal_Second_Intermediary_Address = record2.Internal_Second_Intermediary_Address;
                    Internal_Second_Intermediary_IsFI = record2.Internal_Second_Intermediary_IsFI;
                    Internal_Second_Intermediary_Delivery_Code = record2.Internal_Second_Intermediary_Delivery_Code;
                    internal_Final_Beneficiary_Name = record2.Internal_Final_Beneficiary_Name;
                    internal_Final_Beneficiary_Account_Number = record2.Internal_Final_Beneficiary_Account_Number;
                    internal_Final_Beneficiary_BIC_Code = record2.Internal_Final_Beneficiary_BIC_Code;
                    internal_Final_Beneficiary_Address = record2.Internal_Final_Beneficiary_Address;
                    internal_Final_Beneficiary_IsFi = record2.Internal_Final_Beneficiary_IsFI;
                    internal_Final_Beneficiary_Delivery_Code = record2.Internal_Final_Beneficiary_Delivery_Code;
                    Internal_Ordering_Institution_Name = record2.Internal_Ordering_Institution_Name;
                    Internal_Ordering_Institution_Account_Number = record2.Internal_Ordering_Institution_Account_Number;
                    Internal_Ordering_Institution_BIC_Code = record2.Internal_Ordering_Institution_BIC_Code;
                    Internal_Ordering_Institution_Address = record2.Internal_Ordering_Institution_Address;
                    Internal_Ordering_Institution_IsFI = record2.Internal_Ordering_Institution_IsFI;
                    Internal_Ordering_Institution_Delivery_Code = record2.Internal_Ordering_Institution_Delivery_Code;
                    External_First_Intermediary_Name = record2.External_First_Intermediary_Name;
                    External_First_Intermediary_Account_Number = record2.External_First_Intermediary_Account_Number;
                    External_First_Intermediary_BIC_Code = record2.External_First_Intermediary_BIC_Code;
                    External_First_Intermediary_Address = record2.External_First_Intermediary_Address;
                    External_First_Intermediary_IsFI = record2.External_First_Intermediary_IsFI;
                    External_First_Intermediary_Delivery_Code = record2.External_First_Intermediary_Delivery_Code;
                    External_Second_Intermediary_Name = record2.External_Second_Intermediary_Name;
                    External_Second_Intermediary_Account_Number = record2.External_Second_Intermediary_Account_Number;
                    External_Second_Intermediary_BIC_Code = record2.External_Second_Intermediary_BIC_Code;
                    External_Second_Intermediary_Address = record2.External_Second_Intermediary_Address;
                    External_Second_Intermediary_IsFI = record2.External_Second_Intermediary_IsFI;
                    External_Second_Intermediary_Delivery_Code = record2.External_Second_Intermediary_Delivery_Code;
                    external_Final_Beneficiary_Name = record2.External_Final_Beneficiary_Name;
                    external_Final_Beneficiary_Account_Number = record2.External_Final_Beneficiary_Account_Number;
                    external_Final_Beneficiary_BIC_Code = record2.External_Final_Beneficiary_BIC_Code;
                    external_Final_Beneficiary_Address = record2.External_Final_Beneficiary_Address;
                    external_Final_Beneficiary_IsFi = record2.External_Final_Beneficiary_IsFI;
                    external_Final_Beneficiary_Delivery_Code = record2.External_Final_Beneficiary_Delivery_Code;
                    External_Ordering_Institution_Name = record2.External_Ordering_Institution_Name;
                    External_Ordering_Institution_Account_Number = record2.External_Ordering_Institution_Account_Number;
                    External_Ordering_Institution_BIC_Code = record2.External_Ordering_Institution_BIC_Code;
                    External_Ordering_Institution_Address = record2.External_Ordering_Institution_Address;
                    External_Ordering_Institution_IsFI = record2.External_Ordering_Institution_IsFI;
                    External_Ordering_Institution_Delivery_Code = record2.External_Ordering_Institution_Delivery_Code;
                    send_Flag = record2.Send_Flag;
                    ackNack = record2.ACK_NACK;
                    settledMsgrcvd = record2.Settled_MsgRcvd;
                    settlementReferenceString = record2.Settlement_ReferenceString;
                    if (record2.CustidialAmount == null)
                    {
                        custodialAmount = 0;
                    }
                    else
                    {
                        custodialAmount = double.Parse(record2.CustidialAmount.ToString());
                    }
                    custodialSwiftOriginal = record2.CustodialSwiftOriginal;
                    swiftMessage = record2.SwiftMessage;
                    cancelflag = record2.Cancelflag;
                    cancelDatetime = Convert.ToDateTime(record2.CancelDateTime, System.Globalization.CultureInfo.GetCultureInfo("hi-IN").DateTimeFormat);
                    cancelAckNack = record2.CancelAckNack;
                    cancelAckNackDatetime = Convert.ToDateTime(record2.CancelAckNackDateTime, System.Globalization.CultureInfo.GetCultureInfo("hi-IN").DateTimeFormat);
                    approverId = int.Parse(record2.ApproverID.ToString());
                    approveFlag = record2.ApproveFlag;
                    reviewFlag = record2.ReviewFlag;
                    approveDatetime = Convert.ToDateTime(record2.ApproveDateTime, System.Globalization.CultureInfo.GetCultureInfo("hi-IN").DateTimeFormat);

                }
            }

        }
        public void InitDataMemberForCancel()
        {
            ExeConfigurationFileMap configFileMap = new ExeConfigurationFileMap();
            configFileMap.ExeConfigFilename = Path.GetFullPath(@"E:\Dealgen\ESP\Swift\bcfconfig.cfg");
            Configuration config = ConfigurationManager.OpenMappedExeConfiguration(configFileMap, ConfigurationUserLevel.None);
            ConnectionStringsSection appsetting = (ConnectionStringsSection)config.GetSection("connectionStrings");
            string connection = ConfigurationManager.ConnectionStrings["DealGenSwiftMessages.Properties.Settings.dbDGDp1ConnectionString"].ConnectionString;

            using (SwiftMessagesDataContext sd2 = new SwiftMessagesDataContext(connection))
            {

                string YesFlag = "Y";

                var recorddatamembercancel = (from i in sd2.t_SwiftTransfers
                                              where i.session_ID != null && i.ReferenceString != null && i.Cancelflag == YesFlag && i.CancelDateTime == null && i.Settled_MsgRcvd == null
                                              select i).FirstOrDefault();

                if (recorddatamembercancel != null)
                {
                    SwiftTransferRecordId = recorddatamembercancel.SwiftTransferRecordId;
                    dealId = recorddatamembercancel.DealId;
                    investmentId = recorddatamembercancel.InvestmentId;
                    fundingActualId = recorddatamembercancel.FundingActualId;
                    transactionId = recorddatamembercancel.TransactionId;
                    transactionBreakdownId = recorddatamembercancel.TransactionBreakdownId;
                    if (recorddatamembercancel.IssuerId == null)
                    {
                        issuerId = 0;
                    }
                    else
                    {
                        issuerId = (decimal)recorddatamembercancel.IssuerId; ;
                    }
                    investmentCd = recorddatamembercancel.InvestmentCd;
                    investmentDescription = recorddatamembercancel.InvestmentDescription;
                    
                    if (recorddatamembercancel.LegalEntityId == null)
                    {
                        legalEntityId = 0;
                    }
                    else
                    {
                        legalEntityId = (decimal)recorddatamembercancel.LegalEntityId;
                    }

                    session_Id = recorddatamembercancel.session_ID;
                    if (recorddatamembercancel.Amount == null)
                    {
                        amount = 0;
                    }
                    else
                    {
                        amount = double.Parse(recorddatamembercancel.Amount.ToString());
                    }
                    currency = recorddatamembercancel.Currency;
                    eventDate = Convert.ToDateTime(recorddatamembercancel.EventDate, System.Globalization.CultureInfo.GetCultureInfo("hi-IN").DateTimeFormat);
                    username = recorddatamembercancel.Username;
                    referenceString = recorddatamembercancel.ReferenceString;
                    internal_First_Intermediary_Name = recorddatamembercancel.Internal_First_Intermediary_Name;
                    internal_First_Intermediary_Account_Number = recorddatamembercancel.Internal_First_Intermediary_Account_Number;
                    internal_First_Intermediary_BIC_Code = recorddatamembercancel.Internal_First_Intermediary_BIC_Code;
                    internal_First_Intermediary_Address = recorddatamembercancel.Internal_First_Intermediary_Address;
                    internal_First_Intermediary_IsFi = recorddatamembercancel.Internal_First_Intermediary_IsFI;
                    internal_First_Intermediary_Delivery_Code = recorddatamembercancel.Internal_First_Intermediary_Delivery_Code;
                    Internal_Second_Intermediary_Name = recorddatamembercancel.Internal_Second_Intermediary_Name;
                    Internal_Second_Intermediary_Account_Number = recorddatamembercancel.Internal_Second_Intermediary_Account_Number;
                    Internal_Second_Intermediary_BIC_Code = recorddatamembercancel.Internal_Second_Intermediary_BIC_Code;
                    Internal_Second_Intermediary_Address = recorddatamembercancel.Internal_Second_Intermediary_Address;
                    Internal_Second_Intermediary_IsFI = recorddatamembercancel.Internal_Second_Intermediary_IsFI;
                    Internal_Second_Intermediary_Delivery_Code = recorddatamembercancel.Internal_Second_Intermediary_Delivery_Code;
                    internal_Final_Beneficiary_Name = recorddatamembercancel.Internal_Final_Beneficiary_Name;
                    internal_Final_Beneficiary_Account_Number = recorddatamembercancel.Internal_Final_Beneficiary_Account_Number;
                    internal_Final_Beneficiary_BIC_Code = recorddatamembercancel.Internal_Final_Beneficiary_BIC_Code;
                    internal_Final_Beneficiary_IsFi = recorddatamembercancel.Internal_Final_Beneficiary_IsFI;
                    internal_Final_Beneficiary_Address = recorddatamembercancel.Internal_Final_Beneficiary_Address;
                    internal_Final_Beneficiary_Delivery_Code = recorddatamembercancel.Internal_Final_Beneficiary_Delivery_Code;
                    Internal_Ordering_Institution_Name = recorddatamembercancel.Internal_Ordering_Institution_Name;
                    Internal_Ordering_Institution_Account_Number = recorddatamembercancel.Internal_Ordering_Institution_Account_Number;
                    Internal_Ordering_Institution_BIC_Code = recorddatamembercancel.Internal_Ordering_Institution_BIC_Code;
                    Internal_Ordering_Institution_Address = recorddatamembercancel.Internal_Ordering_Institution_Address;
                    Internal_Ordering_Institution_IsFI = recorddatamembercancel.Internal_Ordering_Institution_IsFI;
                    Internal_Ordering_Institution_Delivery_Code = recorddatamembercancel.Internal_Ordering_Institution_Delivery_Code;
                    External_First_Intermediary_Name = recorddatamembercancel.External_First_Intermediary_Name;
                    External_First_Intermediary_Account_Number = recorddatamembercancel.External_First_Intermediary_Account_Number;
                    External_First_Intermediary_BIC_Code = recorddatamembercancel.External_First_Intermediary_BIC_Code;
                    External_First_Intermediary_Address = recorddatamembercancel.External_First_Intermediary_Address;
                    External_First_Intermediary_IsFI = recorddatamembercancel.External_First_Intermediary_IsFI;
                    External_First_Intermediary_Delivery_Code = recorddatamembercancel.External_First_Intermediary_Delivery_Code;
                    External_Second_Intermediary_Name = recorddatamembercancel.External_Second_Intermediary_Name;
                    External_Second_Intermediary_Account_Number = recorddatamembercancel.External_Second_Intermediary_Account_Number;
                    External_Second_Intermediary_BIC_Code = recorddatamembercancel.External_Second_Intermediary_BIC_Code;
                    External_Second_Intermediary_Address = recorddatamembercancel.External_Second_Intermediary_Address;
                    External_Second_Intermediary_IsFI = recorddatamembercancel.External_Second_Intermediary_IsFI;
                    External_Second_Intermediary_Delivery_Code = recorddatamembercancel.External_Second_Intermediary_Delivery_Code;
                    external_Final_Beneficiary_Name = recorddatamembercancel.External_Final_Beneficiary_Name;
                    external_Final_Beneficiary_Account_Number = recorddatamembercancel.External_Final_Beneficiary_Account_Number;
                    external_Final_Beneficiary_BIC_Code = recorddatamembercancel.External_Final_Beneficiary_BIC_Code;
                    external_Final_Beneficiary_Address = recorddatamembercancel.External_Final_Beneficiary_Address;
                    external_Final_Beneficiary_IsFi = recorddatamembercancel.External_Final_Beneficiary_IsFI;
                    external_Final_Beneficiary_Delivery_Code = recorddatamembercancel.External_Final_Beneficiary_Delivery_Code;
                    External_Ordering_Institution_Name = recorddatamembercancel.External_Ordering_Institution_Name;
                    External_Ordering_Institution_Account_Number = recorddatamembercancel.External_Ordering_Institution_Account_Number;
                    External_Ordering_Institution_BIC_Code = recorddatamembercancel.External_Ordering_Institution_BIC_Code;
                    External_Ordering_Institution_Address = recorddatamembercancel.External_Ordering_Institution_Address;
                    External_Ordering_Institution_IsFI = recorddatamembercancel.External_Ordering_Institution_IsFI;
                    External_Ordering_Institution_Delivery_Code = recorddatamembercancel.External_Ordering_Institution_Delivery_Code;
                    send_Flag = recorddatamembercancel.Send_Flag;
                    ackNack = recorddatamembercancel.ACK_NACK;
                    settledMsgrcvd = recorddatamembercancel.Settled_MsgRcvd;
                    settlementReferenceString = recorddatamembercancel.Settlement_ReferenceString;
                    if (recorddatamembercancel.CustidialAmount == null)
                    {
                        custodialAmount = 0;
                    }
                    else
                    {
                        custodialAmount = double.Parse(recorddatamembercancel.CustidialAmount.ToString());
                    }
                    custodialSwiftOriginal = recorddatamembercancel.CustodialSwiftOriginal;
                    swiftMessage = recorddatamembercancel.SwiftMessage;
                    cancelflag = recorddatamembercancel.Cancelflag;
                    cancelDatetime = Convert.ToDateTime(recorddatamembercancel.CancelDateTime, System.Globalization.CultureInfo.GetCultureInfo("hi-IN").DateTimeFormat);

                    cancelAckNack = recorddatamembercancel.CancelAckNack;
                    cancelAckNackDatetime = Convert.ToDateTime(recorddatamembercancel.CancelAckNackDateTime, System.Globalization.CultureInfo.GetCultureInfo("hi-IN").DateTimeFormat);
                    approverId = int.Parse(recorddatamembercancel.ApproverID.ToString());
                    approveFlag = recorddatamembercancel.ApproveFlag;
                    reviewFlag = recorddatamembercancel.ReviewFlag;
                    approveDatetime = Convert.ToDateTime(recorddatamembercancel.ApproveDateTime, System.Globalization.CultureInfo.GetCultureInfo("hi-IN").DateTimeFormat);


                }
            }
        }
        public void GetSessionId()
        {

            Console.WriteLine("Getting the Session ID");
            ExeConfigurationFileMap configFileMap = new ExeConfigurationFileMap();
            configFileMap.ExeConfigFilename = Path.GetFullPath(@"E:\Dealgen\ESP\Swift\bcfconfig.cfg");
            //Console.WriteLine("ConfigFileMap - ", configFileMap);
            Configuration config = ConfigurationManager.OpenMappedExeConfiguration(configFileMap, ConfigurationUserLevel.None);
            ConnectionStringsSection appsetting = (ConnectionStringsSection)config.GetSection("connectionStrings");
            string connection = ConfigurationManager.ConnectionStrings["DealGenSwiftMessages.Properties.Settings.dbDGDp1ConnectionString"].ConnectionString;
            
            System.Data.SqlClient.SqlConnectionStringBuilder builder = new System.Data.SqlClient.SqlConnectionStringBuilder(connection);
            string datasource = builder.DataSource;
            string databasename = builder.InitialCatalog;
            
            AppSettingsSection SwiftRegistrationUrl = (AppSettingsSection)config.GetSection("appSettings");
            var swiftregistrationurl = SwiftRegistrationUrl.Settings["SwiftRegistrationUrl"].Value;
         
            var registration = new ClientRegistration()
            {
                //CallbackUrl = "http://dev-apexswift-inv.manulife.com/Service.svc/RestPostCallback",
                //8/31/2017 CallbackUrl = "http://MLISGCLDB0082.americas.manulife.net:9051/api/Onswiftevent ",
                //CallbackUrl = "http://b04bcfd02.dev.manulifeusa.com:9090/api/Onswiftevent ",
                CallbackUrl = swiftregistrationurl,
                Type = 0,
                ClientName = "DealGen",
                AckTimeout = 15,
                AlertEmail = "BCFITSupportTeam@jhancock.com",
                DatabaseName = databasename,
                DatabaseServer = datasource,

            };

            var CL = new HttpClient();
            var client = new HttpClient(new HttpClientHandler() { UseDefaultCredentials = true});
            var serializer = new JavaScriptSerializer();
            var json = serializer.Serialize(registration);
            var request = new StringContent(json, Encoding.UTF8, "application/json");
            //var sessionId = client.PostAsync("http://10.101.133.92:9050/api/Clients", request).Result.Content.ReadAsStringAsync().Result;
            //var sessionId = client.PostAsync("http://mlisgcldb0082.americas.manulife.net:9050/api/Clients", request).Result.Content.ReadAsStringAsync().Result;

            var sessionUrl = SwiftRegistrationUrl.Settings["sessionUrl"].Value;
            
            System.Net.ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072; //This is required for .Net 4.0 for TLS1.2 SSL
            ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true; //This is required for ignoring SSL Trust Error
          
            //var sessionId = client.PostAsync("http://10.101.133.92:9061/api/Clients", request).Result.Content.ReadAsStringAsync().Result;
        
            //var sessionId = client.PostAsync(sessionUrl, request).Result.Content.ReadAsStringAsync().Result;
           
            char[] thisChar = { '\\', '\"' };
            //string[] SessionID = sessionId.Split(thisChar);
            //session_Id = SessionID[1];
            session_Id = "c52712df-d1c1-41";
            string con = ConfigurationManager.ConnectionStrings["DealGenSwiftMessages.Properties.Settings.dbDGDp1ConnectionString"].ConnectionString;
            
           
            if (session_Id == null)
            {
                throw new Exception("Failed to get an Seesion ID from SWIFT.");
            }
            else
            {
                using (SwiftMessagesDataContext updtMT202 = new SwiftMessagesDataContext(con))
                {
                    var updaterecordMT202 = from c in updtMT202.t_SwiftTransfers
                                            where c.ReferenceString.StartsWith(referenceString)
                                            select c;
                    foreach (var updatedataMT202 in updaterecordMT202)
                    {
                        updatedataMT202.session_ID = session_Id;
                    }

                    updtMT202.SubmitChanges();
                }

                Console.WriteLine("Seesion ID has been recieved successfully.. ");
            }
        
        }
        public void SendMT202Message()
        {
                     //-----------------------Sending MT202 Wire Instruction To SWIFT --------------------

            Console.WriteLine("Sending MT202 Message to Swift");
            InstitutionalTransfer ts = new InstitutionalTransfer();
            ts.InternalInstitution = new Mfc.Inv.Swift.Common.Common.ThirdPartyInfos();
            ts.InternalInstitution.FirstIntermediary = new Mfc.Inv.Swift.Common.Common.ThirdParty();
            ts.InternalInstitution.SecondIntermediary = new Mfc.Inv.Swift.Common.Common.ThirdParty();
            ts.InternalInstitution.FinalBeneficiary = new Mfc.Inv.Swift.Common.Common.ThirdParty();
            ts.InternalInstitution.OrderingInstitution = new Mfc.Inv.Swift.Common.Common.ThirdParty();
            ts.ExternalInstitution = new Mfc.Inv.Swift.Common.Common.ThirdPartyInfos();
            ts.ExternalInstitution.FirstIntermediary = new Mfc.Inv.Swift.Common.Common.ThirdParty();
            ts.ExternalInstitution.FinalBeneficiary = new Mfc.Inv.Swift.Common.Common.ThirdParty();
            ts.ExternalInstitution.SecondIntermediary = new Mfc.Inv.Swift.Common.Common.ThirdParty();
            ts.ExternalInstitution.OrderingInstitution = new Mfc.Inv.Swift.Common.Common.ThirdParty();
            ts.MessageSenderInfo = new Mfc.Inv.Swift.Common.Common.MessageSenderInfo();
            ExeConfigurationFileMap configFileMap = new ExeConfigurationFileMap();
            configFileMap.ExeConfigFilename = Path.GetFullPath(@"E:\Dealgen\ESP\Swift\bcfconfig.cfg");
            Configuration config = ConfigurationManager.OpenMappedExeConfiguration(configFileMap, ConfigurationUserLevel.None);
            ConnectionStringsSection appsetting = (ConnectionStringsSection)config.GetSection("connectionStrings");
            string connection = ConfigurationManager.ConnectionStrings["DealGenSwiftMessages.Properties.Settings.dbDGDp1ConnectionString"].ConnectionString;
            System.Data.SqlClient.SqlConnectionStringBuilder builder = new System.Data.SqlClient.SqlConnectionStringBuilder(connection);
            string datasource = builder.DataSource;
            string databasename = builder.InitialCatalog;
            AppSettingsSection appsettingsection = (AppSettingsSection)config.GetSection("appSettings");
            ts.MessageSenderInfo.DatabaseServer = datasource;
            ts.MessageSenderInfo.DatabaseName = databasename;
            //ts.MessageSenderInfo.User = "spreadg";
            ts.MessageSenderInfo.User = username;
            ts.SessionId = session_Id;
            ts.Amount = Convert.ToDecimal(amount);
            ts.Currency = currency;
            ts.EventDate = eventDate;
            ts.ReferenceString = referenceString;
            ts.InternalInstitution.FirstIntermediary.Name = internal_First_Intermediary_Name;
            ts.InternalInstitution.FirstIntermediary.AccountNumber = internal_First_Intermediary_Account_Number;
            ts.InternalInstitution.FirstIntermediary.BicCode = internal_First_Intermediary_BIC_Code;
            ts.InternalInstitution.FirstIntermediary.Address = internal_First_Intermediary_Address;
            ts.InternalInstitution.FirstIntermediary.IsFinancialInstitution = Convert.ToBoolean(internal_First_Intermediary_IsFi);
            ts.InternalInstitution.FirstIntermediary.DeliveryCode = internal_First_Intermediary_Delivery_Code;
            //Adding New field (Secondary and Ordering)in MT202 Message
            ts.InternalInstitution.SecondIntermediary.Name = Internal_Second_Intermediary_Name;
            ts.InternalInstitution.SecondIntermediary.AccountNumber = Internal_Second_Intermediary_Account_Number;
            ts.InternalInstitution.SecondIntermediary.BicCode = Internal_Second_Intermediary_BIC_Code;
            ts.InternalInstitution.SecondIntermediary.Address = Internal_Second_Intermediary_Address;
            ts.InternalInstitution.SecondIntermediary.IsFinancialInstitution = Convert.ToBoolean(Internal_Second_Intermediary_IsFI);
            ts.InternalInstitution.SecondIntermediary.DeliveryCode = Internal_Second_Intermediary_Delivery_Code;

            ts.InternalInstitution.FinalBeneficiary.Name = internal_Final_Beneficiary_Account_Number;
            ts.InternalInstitution.FinalBeneficiary.AccountNumber = internal_Final_Beneficiary_Account_Number;
            ts.InternalInstitution.FinalBeneficiary.BicCode = internal_Final_Beneficiary_BIC_Code; //MFCTUS30
            ts.InternalInstitution.FinalBeneficiary.Address = internal_Final_Beneficiary_Address;
            ts.InternalInstitution.FinalBeneficiary.IsFinancialInstitution = Convert.ToBoolean(internal_Final_Beneficiary_IsFi);
            ts.InternalInstitution.FinalBeneficiary.DeliveryCode = internal_Final_Beneficiary_Delivery_Code;

            ts.InternalInstitution.OrderingInstitution.Name = Internal_Ordering_Institution_Name;
            ts.InternalInstitution.OrderingInstitution.AccountNumber = Internal_Ordering_Institution_Account_Number;
            ts.InternalInstitution.OrderingInstitution.BicCode = Internal_Ordering_Institution_BIC_Code;
            ts.InternalInstitution.OrderingInstitution.Address = Internal_Ordering_Institution_Address;
            ts.InternalInstitution.OrderingInstitution.IsFinancialInstitution = Convert.ToBoolean(Internal_Ordering_Institution_IsFI);
            ts.InternalInstitution.OrderingInstitution.DeliveryCode = Internal_Ordering_Institution_Delivery_Code;

            //Adding External First , Secondary and ordering Bank information for MT202 Message

            ts.ExternalInstitution.FirstIntermediary.Name = External_First_Intermediary_Name;
            ts.ExternalInstitution.FirstIntermediary.AccountNumber = External_First_Intermediary_Account_Number;
            ts.ExternalInstitution.FirstIntermediary.BicCode = External_First_Intermediary_BIC_Code;
            ts.ExternalInstitution.FirstIntermediary.Address = External_First_Intermediary_Address;
            ts.ExternalInstitution.FirstIntermediary.IsFinancialInstitution = Convert.ToBoolean(External_First_Intermediary_IsFI);
            ts.ExternalInstitution.FirstIntermediary.DeliveryCode = External_First_Intermediary_Delivery_Code;

            ts.ExternalInstitution.SecondIntermediary.Name = External_Second_Intermediary_Name;
            ts.ExternalInstitution.SecondIntermediary.AccountNumber=External_Second_Intermediary_Account_Number;
            ts.ExternalInstitution.SecondIntermediary.BicCode=External_Second_Intermediary_BIC_Code;
            ts.ExternalInstitution.SecondIntermediary.Address=External_Second_Intermediary_Address;
            ts.ExternalInstitution.SecondIntermediary.IsFinancialInstitution = Convert.ToBoolean(External_Second_Intermediary_IsFI);
            ts.ExternalInstitution.SecondIntermediary.DeliveryCode = External_Second_Intermediary_Delivery_Code;

            ts.ExternalInstitution.FinalBeneficiary.Name = external_Final_Beneficiary_Name;
            ts.ExternalInstitution.FinalBeneficiary.AccountNumber = external_Final_Beneficiary_Account_Number;
            ts.ExternalInstitution.FinalBeneficiary.BicCode = external_Final_Beneficiary_BIC_Code;
            ts.ExternalInstitution.FinalBeneficiary.Address = external_Final_Beneficiary_Address;
            ts.ExternalInstitution.FinalBeneficiary.IsFinancialInstitution = Convert.ToBoolean(external_Final_Beneficiary_IsFi);
            ts.ExternalInstitution.FinalBeneficiary.DeliveryCode = external_Final_Beneficiary_Delivery_Code;
      
            ts.ExternalInstitution.OrderingInstitution.Name = External_Ordering_Institution_Name;
            ts.ExternalInstitution.OrderingInstitution.BicCode=External_Ordering_Institution_BIC_Code;
            ts.ExternalInstitution.OrderingInstitution.AccountNumber=External_Ordering_Institution_Account_Number;
            ts.ExternalInstitution.OrderingInstitution.Address=External_Ordering_Institution_Address;
            ts.ExternalInstitution.OrderingInstitution.IsFinancialInstitution=Convert.ToBoolean(External_Ordering_Institution_IsFI);
            ts.ExternalInstitution.OrderingInstitution.DeliveryCode=External_Ordering_Institution_Delivery_Code;


            var client = new HttpClient(new HttpClientHandler() { UseDefaultCredentials=true});
            var serializer = new JavaScriptSerializer();
            var jsonMT202 = serializer.Serialize(ts);
            var requestMT202 = new StringContent(jsonMT202, Encoding.UTF8, "application/json");

            var MT202Url = appsettingsection.Settings["MT202Url"].Value;
            //var Output = client.PostAsync("http://mlisgcldb0082.americas.manulife.net:9050/api/InstitutionalTransfer", requestMT202).Result.Content.ReadAsStringAsync().Result;
            //var Output = client.PostAsync("http://10.101.133.92:9061/api/InstitutionalTransfer", requestMT202).Result.Content.ReadAsStringAsync().Result;
            System.Net.ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072; //This is required for .Net 4.0 for TLS1.2 SSL
            ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true; //This is required for ignoring SSL Trust Error
            var Output = client.PostAsync(MT202Url, requestMT202).Result.Content.ReadAsStringAsync().Result;
            
            string con = ConfigurationManager.ConnectionStrings["DealGenSwiftMessages.Properties.Settings.dbDGDp1ConnectionString"].ConnectionString;
            using (SwiftMessagesDataContext updt = new SwiftMessagesDataContext(con))
            {

                var updateSenttime = from c in updt.t_SwiftTransfers
                                     where c.ReferenceString.StartsWith(referenceString)
                                     select c;
                foreach (var updatedata in updateSenttime)
                {
                    updatedata.SentDateTime = DateTime.Now;
                }

                updt.SubmitChanges();
            }

                         // -------------- Sending Notification Incase any Error occured -----------------------

            var Job = "DGDD_SwiftMessage";
            UtilCls.CBCFUtilities _Util = new UtilCls.CBCFUtilities();
            var mailtousers = appsettingsection.Settings["bcfmail"].Value;
            var mailfrom = appsettingsection.Settings["bcfmail"].Value;
            var jobname = Job + "::";

            Dictionary<string, object> result = (serializer.DeserializeObject(Output) as Dictionary<string, object>);
            bool inError = bool.Parse((result["InError"]).ToString());
            if (inError)
            {
                var ErrorMessage = (result["ErrorMessage"].ToString());

                //---------------  Insert Error Notification to DataBase ------------------------

                string conError = ConfigurationManager.ConnectionStrings["DealGenSwiftMessages.Properties.Settings.dbDGDp1ConnectionString"].ConnectionString;
                using (SwiftMessagesDataContext Insert = new SwiftMessagesDataContext(conError))
                {
                    t_SwiftErrorMessage errmsg = new t_SwiftErrorMessage();
                    errmsg.SwiftTransferRecordId = SwiftTransferRecordId;
                    errmsg.ReferenceString = referenceString;
                    errmsg.ErrorMessage = ErrorMessage.ToString();
                    errmsg.EntryDtTm = DateTime.Now;

                    Insert.t_SwiftErrorMessages.InsertOnSubmit(errmsg);
                    Insert.SubmitChanges();
                }

                throw new Exception(ErrorMessage + "For referencestring : '"+ referenceString+"'");

            }
            else
            {
                _Util.SendNotificationEmailXP(mailfrom, mailtousers, "Notification : '" + jobname + "' Success.", "Message has been sent Successfully to Swift for referencestring : '" + referenceString + "' and CUSIP : '" + investmentCd + "' on '" + DateTime.Now.ToString() + "' to'" + external_Final_Beneficiary_Name + "' Bank for amout :'" + -(amount) + "'.Settlement date is '" + eventDate + "' ", "", "", "");
                    Console.WriteLine("MT202 has been Sent Successfully.!!!");    
            }
      
            
        }
        public void CancellationRequest()
        {
                                    // ------------------ Sending Cancelation request to SWIFT --------------------

            Console.WriteLine("Sending MT292 cancelation Message to Swift");
            CancellationRequest cancel = new Mfc.Inv.Swift.Common.Messages.CancellationRequest();
            cancel.MessageSenderInfo = new Mfc.Inv.Swift.Common.Common.MessageSenderInfo();
            ExeConfigurationFileMap configFileMap = new ExeConfigurationFileMap();
            configFileMap.ExeConfigFilename = Path.GetFullPath(@"E:\Dealgen\ESP\Swift\bcfconfig.cfg");
            Configuration config = ConfigurationManager.OpenMappedExeConfiguration(configFileMap, ConfigurationUserLevel.None);
            ConnectionStringsSection appsetting = (ConnectionStringsSection)config.GetSection("connectionStrings");
            string connection = ConfigurationManager.ConnectionStrings["DealGenSwiftMessages.Properties.Settings.dbDGDp1ConnectionString"].ConnectionString;
            System.Data.SqlClient.SqlConnectionStringBuilder builder = new System.Data.SqlClient.SqlConnectionStringBuilder(connection);
            string datasource = builder.DataSource;
            string databasename = builder.InitialCatalog;
            cancel.MessageSenderInfo.DatabaseName = databasename;
            cancel.MessageSenderInfo.DatabaseServer = datasource;
            cancel.MessageSenderInfo.User = username;
            cancel.ReferenceString = string.Concat(referenceString, "C");
            cancel.CancellationReferenceString = referenceString;
            cancel.SessionId = session_Id;
            AppSettingsSection appsettingsection = (AppSettingsSection)config.GetSection("appSettings");

            var Job = "DGDD_SwiftMessage";
            UtilCls.CBCFUtilities _Util = new UtilCls.CBCFUtilities();
            var mailtousers = appsettingsection.Settings["bcfmail"].Value;
            var mailfrom = appsettingsection.Settings["bcfmail"].Value;
            
            var jobname = Job + "::";

            var client = new HttpClient(new HttpClientHandler() { UseDefaultCredentials=true });
            var serializer = new JavaScriptSerializer();
            var JsoncancelrequestMT202 = serializer.Serialize(cancel);
            var cancelrequestMT202 = new StringContent(JsoncancelrequestMT202, Encoding.UTF8, "application/json");

            var CancelUrl = appsettingsection.Settings["CancelUrl"].Value;
            //var result = client.PostAsync("http://mlisgcldb0082.americas.manulife.net:9050/api/Cancellation", cancelrequestMT202).Result.Content.ReadAsStringAsync().Result;
            //var result = client.PostAsync("http://10.101.133.92:9061/api/Cancellation", cancelrequestMT202).Result.Content.ReadAsStringAsync().Result;
            System.Net.ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072; //This is required for .Net 4.0 for TLS1.2 SSL
            ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true; //This is required for ignoring SSL Trust Error

            var result = client.PostAsync(CancelUrl, cancelrequestMT202).Result.Content.ReadAsStringAsync().Result;

            System.Threading.Thread.Sleep(3000);

            string YesFlag = "Y";

            Dictionary<string, object> cancelresult = (serializer.DeserializeObject(result) as Dictionary<string, object>);

            bool inError = bool.Parse((cancelresult["InError"]).ToString());
            if (inError)
            {
             
                var cancelErrorMessage = cancelresult["ErrorMessage"].ToString();

                string conError = ConfigurationManager.ConnectionStrings["DealGenSwiftMessages.Properties.Settings.dbDGDp1ConnectionString"].ConnectionString;
                using (SwiftMessagesDataContext InsertCancel = new SwiftMessagesDataContext(conError))
                {
                    t_SwiftErrorMessage errmsg = new t_SwiftErrorMessage();
                    errmsg.SwiftTransferRecordId = SwiftTransferRecordId;
                    errmsg.ReferenceString = referenceString;
                    errmsg.ErrorMessage = cancelErrorMessage.ToString();
                    errmsg.EntryDtTm = DateTime.Now;

                    InsertCancel.t_SwiftErrorMessages.InsertOnSubmit(errmsg);
                    InsertCancel.SubmitChanges();
                   
                }

                throw new Exception(cancelErrorMessage + "For referencestring : '" + referenceString + "'");
 
            }
            else
            {
                string con = ConfigurationManager.ConnectionStrings["DealGenSwiftMessages.Properties.Settings.dbDGDp1ConnectionString"].ConnectionString;
                using (SwiftMessagesDataContext updt = new SwiftMessagesDataContext(con))
                {

                    var updaterecord = from c in updt.t_SwiftTransfers
                                       where c.ReferenceString.StartsWith(referenceString) && c.Cancelflag.StartsWith(YesFlag)
                                       select c;
                    foreach (var updatedata in updaterecord)
                    {
                        updatedata.CancelDateTime = DateTime.Now;
                        updatedata.ReferenceString = string.Concat(referenceString, "C");
                    }

                    updt.SubmitChanges();
                }

                _Util.SendNotificationEmailXP(mailfrom, mailtousers, "Notification : '" + jobname + "' Success.", "Cancellation Message has been sent Successfully to Swift for referencestring '" + referenceString + "' and CUSIP : '" + investmentCd + "' on '" + DateTime.Now + "' for Bank '" + external_Final_Beneficiary_Name + "' for Amount : '" + -(amount) + "' ", "", "", "");
                 Console.WriteLine("MT292 cancelation Message has been sent to Swift Successfully..");
            }

         

        }
        public void SendNotifications()
        {
            ExeConfigurationFileMap configFileMap = new ExeConfigurationFileMap();
            configFileMap.ExeConfigFilename = Path.GetFullPath(@"E:\Dealgen\ESP\Swift\bcfconfig.cfg");
            Configuration config = ConfigurationManager.OpenMappedExeConfiguration(configFileMap, ConfigurationUserLevel.None);
            ConnectionStringsSection appsetting = (ConnectionStringsSection)config.GetSection("connectionStrings");
            string connection = ConfigurationManager.ConnectionStrings["DealGenSwiftMessages.Properties.Settings.dbDGDp1ConnectionString"].ConnectionString;
            AppSettingsSection appsettingsection = (AppSettingsSection)config.GetSection("appSettings");

            var Job = "DGDD_SwiftMessage";
            UtilCls.CBCFUtilities _Util = new UtilCls.CBCFUtilities();

            var mailtousers = appsettingsection.Settings["bcfmail"].Value;
            var mailfrom = appsettingsection.Settings["bcfmail"].Value;
            var jobname = Job + "::";

            //using (SwiftMessagesDataContext sd = new SwiftMessagesDataContext(connection))
            //{
            //    string path = @"E:\Dealgen\ESP\Swift\NACK_Record.txt";

            //     var _NackandErrorrecord = (from i in sd.t_SwiftErrorMessages
            //                      where i.EntryDtTm >= DateTime.Today && i.ReferenceString != null && i.SwiftTransferRecordId !=null
            //                      select i.SwiftTransferRecordId);

            //    List<int> Nckrecord = new List<int>();
            //    Nckrecord = _NackandErrorrecord.ToList<int>();

            //    ///var count = recordinit.count();
            //    if (Nckrecord.Count != 0)
            //    {
            //        if (!File.Exists(path))
            //        {
            //            File.Create(path);
            //        }

            //        if (File.Exists(path))
            //        {
            //            File.Delete(path);

            //            TextWriter tw = new StreamWriter(File.Create(path));

            //            foreach (int s in Nckrecord)
            //            {
            //                tw.WriteLine(s);
            //            }

            //            tw.Close();

            //        }

            //        _Util.SendNotificationEmailXP(mailfrom, mailtousers, "Notification : '" + jobname + "' Success.", "Acknowledgement has been recieved from SWIFT. \n Note : For NACK and InError Achknowledgement please find the attached sheet Please do the fix as soon as possible for mentioned SwiftTransferRecordId in attachment.\n Note : For received NACK and Inerror Messages please refer the t_SwiftErrorMessage and t_SwiftTransfer tables Table in dbhldp1 Database. ", path, "", "");
            //        //File.Delete(path);

            //    }
            //    else
            //    {
            //        _Util.SendNotificationEmailXP(mailfrom, mailtousers, "Notification : '" + jobname + "' Success.", "Ackknowledgement has been received Successfully from the Swift for all the referencestring for '" + DateTime.Today + "' ", "", "", "");

            //    }
            //}

            _Util.SendNotificationEmailXP(mailfrom, mailtousers, "Notification : '" + jobname + "' Success.", "Message has been sent Successfully to Swift all referencestring for '" + DateTime.Today + "' " + " " + " for Bank '" + external_Final_Beneficiary_Name + "' " + " Settlement date is '" + eventDate + "' " + " And the Amount is '" + amount + "' ", "", "", "");
        }
        public static bool InitSettle()
        {
            Console.WriteLine("Getting Config file");
            ExeConfigurationFileMap configFileMap = new ExeConfigurationFileMap();
            configFileMap.ExeConfigFilename = Path.GetFullPath(@"E:\Dealgen\ESP\Swift\bcfconfig.cfg");   //("""","")) + " \bcfconfig.cfg "));
            Configuration config = ConfigurationManager.OpenMappedExeConfiguration(configFileMap, ConfigurationUserLevel.None);
            ConnectionStringsSection appsetting = (ConnectionStringsSection)config.GetSection("connectionStrings");

            string connection = ConfigurationManager.ConnectionStrings["DealGenSwiftMessages.Properties.Settings.dbDGDp1ConnectionString"].ConnectionString;
            string YesFlag = "Y";
            string NoFlag = "N";

            using (SwiftMessagesDataContext sd = new SwiftMessagesDataContext(connection))
            {

                var recordinitsettle = (from i in sd.t_SwiftTransfers
                                  where i.session_ID != null && (i.Cancelflag == null || i.Cancelflag == NoFlag) && i.ApproveFlag == YesFlag && i.ReviewFlag == YesFlag && i.Settled_MsgRcvd == YesFlag && i.SettleUserNotification == null && i.Settled_DateTime < DateTime.Now
                                  select i).FirstOrDefault();

                //var count = sd.t_SwiftTransfers.Count(recordinit => recordinit.session_ID == this  )
                ///var count = recordinit.count();
                if (recordinitsettle != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            
        }
        public void InitdatamemberForSettlement()
        {
            ExeConfigurationFileMap configFileMap = new ExeConfigurationFileMap();
            configFileMap.ExeConfigFilename = Path.GetFullPath(@"E:\Dealgen\ESP\Swift\bcfconfig.cfg");
            Configuration config = ConfigurationManager.OpenMappedExeConfiguration(configFileMap, ConfigurationUserLevel.None);
            ConnectionStringsSection appsetting = (ConnectionStringsSection)config.GetSection("connectionStrings");
            string connection = ConfigurationManager.ConnectionStrings["DealGenSwiftMessages.Properties.Settings.dbDGDp1ConnectionString"].ConnectionString;

            using (SwiftMessagesDataContext sdsettle = new SwiftMessagesDataContext(connection))
            {

                string YesFlag = "Y";
                string NoFlag = "N";

                var recordinitsettle = (from i in sdsettle.t_SwiftTransfers
                                  where i.session_ID != null && (i.Cancelflag == null || i.Cancelflag == NoFlag) && i.ApproveFlag == YesFlag && i.ReviewFlag == YesFlag && i.Settled_MsgRcvd == YesFlag && i.SettleUserNotification == null && i.Settled_DateTime < DateTime.Now
                                  select i).FirstOrDefault();


                if (recordinitsettle != null)
                {
                    referenceString = recordinitsettle.ReferenceString;
                    if (recordinitsettle.Amount == null)
                    {
                        amount = 0;
                    }
                    else
                    {
                        amount = double.Parse(recordinitsettle.Amount.ToString());
                    }
                    external_Final_Beneficiary_Name = recordinitsettle.External_Final_Beneficiary_Name;
                    Settled_DateTime = Convert.ToDateTime(recordinitsettle.Settled_DateTime, System.Globalization.CultureInfo.GetCultureInfo("hi-IN").DateTimeFormat);
                    investmentCd = recordinitsettle.InvestmentCd;
                }

            AppSettingsSection appsettingsection = (AppSettingsSection)config.GetSection("appSettings");
            var Job = "DGDD_SwiftMessage";
            UtilCls.CBCFUtilities _Util = new UtilCls.CBCFUtilities();

            var mailtousers = appsettingsection.Settings["bcfmail"].Value;
            var mailfrom = appsettingsection.Settings["bcfmail"].Value;
            var jobname = Job + "::";
            string Yesflg = "Y";
            using (SwiftMessagesDataContext updtsettle = new SwiftMessagesDataContext(connection))
            {

                var updatSettleUserNotificationt = from c in updtsettle.t_SwiftTransfers
                                     where c.ReferenceString.StartsWith(referenceString)
                                     select c;
                foreach (var updatedata in updatSettleUserNotificationt)
                {
                    updatedata.SettleUserNotification = Yesflg;
                }

                updtsettle.SubmitChanges();
            }

            _Util.SendNotificationEmailXP(mailfrom, mailtousers, "Notification : '" + jobname + "' Success.", "Settle Acknowledgement has been recieved Successfully from Swift for referencestring : '" + referenceString + "' and CUSIP :'" + investmentCd + "' for '" + external_Final_Beneficiary_Name + "' Bank for amout :'" + -(amount) + "'.Settled on '" + Settled_DateTime + "' ", "", "", "");
            
            }
 
        }

    }
    
}
