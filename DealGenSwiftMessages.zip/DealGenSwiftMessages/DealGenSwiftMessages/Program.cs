﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.Web;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;
using Mfc.Inv.Swift.Common;
using Mfc.Inv.Swift.Common.Contracts;
using Mfc.Inv.Swift.Common.Messages;
using System.Web.Script.Serialization;
using System.Text;
using System.Net;
using System.Data;
using System.Data.SqlClient;
using System.Threading;

namespace DealGenSwiftMessages
{
    class Program
    {
        static void Main(string[] args)
        {

            try
            {
                // ------------------------ Sending SWIFT MT202 Message to SWIFT ---------------------------

                Console.WriteLine("Swift Event MT202 Process starting..");
                
                while (SwiftEventProcess.Init())
                {
                    
                    DealGenSwiftMessages.SwiftEventProcess sep = new DealGenSwiftMessages.SwiftEventProcess();

                    sep.InitDataMember();

                    sep.GetSessionId();

                    sep.SendMT202Message();
                    
                    System.Threading.Thread.Sleep(1000);


                }
             
                //--------------------------Sending Cancellation Request to SWIFT ----------------------------
                
                while (SwiftEventProcess.InitCancel())
                {

                    DealGenSwiftMessages.SwiftEventProcess sepCancel = new DealGenSwiftMessages.SwiftEventProcess();

                    sepCancel.InitDataMemberForCancel();

                    sepCancel.CancellationRequest();
                }

               // System.Threading.Thread.Sleep(180000);
               // SwiftEventProcess sendNotifications = new SwiftEventProcess();
                //sendNotifications.SendNotifications();

                while (SwiftEventProcess.InitSettle())
                {
                    DealGenSwiftMessages.SwiftEventProcess sepSettle = new DealGenSwiftMessages.SwiftEventProcess();

                    sepSettle.InitdatamemberForSettlement();

                }
            }

            catch (Exception ex)
            {
                string errormsg=string.Empty;

                errormsg = string.Format("Swift Message error: {0},{1}:", ex.Message, ex.StackTrace);

                if (ex.InnerException != null)
                {
                    errormsg += string.Format("Swift Inner error: {0},{1}", ex.InnerException.Message, ex.InnerException.StackTrace);
                }
                ExeConfigurationFileMap configFileMap = new ExeConfigurationFileMap();
                configFileMap.ExeConfigFilename = Path.GetFileName(@"E:\Dealgen\ESP\Swift\bcfconfig.cfg");
                Configuration config = ConfigurationManager.OpenMappedExeConfiguration(configFileMap, ConfigurationUserLevel.None);
                ConnectionStringsSection appsetting = (ConnectionStringsSection)config.GetSection("connectionStrings");
                string connection = ConfigurationManager.ConnectionStrings["DealGenSwiftMessages.Properties.Settings.dbDGDp1ConnectionString"].ConnectionString;
                AppSettingsSection appsettingsection = (AppSettingsSection)config.GetSection("appSettings");

                var Job = "DGDD_SwiftMessage";
                UtilCls.CBCFUtilities _Util = new UtilCls.CBCFUtilities();

                var mailtousers = appsettingsection.Settings["bcfmail"].Value;
                var mailfrom = appsettingsection.Settings["bcfmail"].Value;
                var jobname = Job + "::";

                _Util.SendNotificationEmailXP(mailfrom, mailtousers, "Notification : '" + jobname + "' Failed.", "Error is : '" + errormsg + "'", "", "", "");
            }

        }
    }
}
