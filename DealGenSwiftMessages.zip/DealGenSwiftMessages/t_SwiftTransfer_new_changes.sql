USE [dbDGDp1]
GO

/****** Object:  Table [dbo].[t_SwiftTransfer]    Script Date: 2/5/2018 10:16:29 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[t_SwiftTransfer](
	[SwiftTransferRecordId] [int] IDENTITY(1,1) NOT NULL,
	[DealId] [numeric](10, 0) NOT NULL,
	[InvestmentId] [numeric](10, 0) NOT NULL,
	[FundingActualId] [numeric](10, 0) NOT NULL,
	[TransactionId] [numeric](10, 0) NOT NULL,
	[TransactionBreakdownId] [numeric](10, 0) NOT NULL,
	[IssuerId] [numeric](10, 0) NULL,
	[InvestmentCd] [char](9) NULL,
	[InvestmentDescription] [varchar](255) NULL,
	[LegalEntityId] [numeric](10, 0) NULL,
	[session_ID] [varchar](50) NULL,
	[Amount] [numeric](20, 2) NULL,
	[Currency] [varchar](50) NULL,
	[EventDate] [datetime] NULL,
	[Username] [varchar](50) NULL,
	[ReferenceString] [varchar](50) NULL,
	[Internal_First_Intermediary_Name] [varchar](50) NULL,
	[Internal_First_Intermediary_Account_Number] [varchar](50) NULL,
	[Internal_First_Intermediary_BIC_Code] [varchar](50) NULL,
	[Internal_First_Intermediary_Address] [varchar](50) NULL,
	[Internal_First_Intermediary_IsFI] [varchar](5) NULL,
	[Internal_First_Intermediary_Delivery_Code] [varchar](50) NULL,
	[Internal_Second_Intermediary_Name] [varchar](50) NULL,
	[Internal_Second_Intermediary_Account_Number] [varchar](50) NULL,
	[Internal_Second_Intermediary_BIC_Code] [varchar](50) NULL,
	[Internal_Second_Intermediary_Address] [varchar](50) NULL,
	[Internal_Second_Intermediary_IsFI] [varchar](5) NULL,
	[Internal_Second_Intermediary_Delivery_Code] [varchar](50) NULL,
	[Internal_Final_Beneficiary_Name] [varchar](50) NULL,
	[Internal_Final_Beneficiary_Account_Number] [varchar](50) NULL,
	[Internal_Final_Beneficiary_BIC_Code] [varchar](50) NULL,
	[Internal_Final_Beneficiary_Address] [varchar](50) NULL,
	[Internal_Final_Beneficiary_IsFI] [varchar](5) NULL,
	[Internal_Final_Beneficiary_Delivery_Code] [varchar](50) NULL,
	[Internal_Ordering_Institution_Name] [varchar](50) NULL,
	[Internal_Ordering_Institution_Account_Number] [varchar](50) NULL,
	[Internal_Ordering_Institution_BIC_Code] [varchar](50) NULL,
	[Internal_Ordering_Institution_Address] [varchar](50) NULL,
	[Internal_Ordering_Institution_IsFI] [varchar](5) NULL,
	[Internal_Ordering_Institution_Delivery_Code] [varchar](50) NULL,
	[External_First_Intermediary_Name] [varchar](50) NULL,
	[External_First_Intermediary_Account_Number] [varchar](50) NULL,
	[External_First_Intermediary_BIC_Code] [varchar](50) NULL,
	[External_First_Intermediary_Address] [varchar](50) NULL,
	[External_First_Intermediary_IsFI] [varchar](5) NULL,
	[External_First_Intermediary_Delivery_Code] [varchar](50) NULL,
	[External_Second_Intermediary_Name] [varchar](50) NULL,
	[External_Second_Intermediary_Account_Number] [varchar](50) NULL,
	[External_Second_Intermediary_BIC_Code] [varchar](50) NULL,
	[External_Second_Intermediary_Address] [varchar](50) NULL,
	[External_Second_Intermediary_IsFI] [varchar](5) NULL,
	[External_Second_Intermediary_Delivery_Code] [varchar](50) NULL,
	[External_Final_Beneficiary_Name] [varchar](50) NULL,
	[External_Final_Beneficiary_Account_Number] [varchar](50) NULL,
	[External_Final_Beneficiary_BIC_Code] [varchar](50) NULL,
	[External_Final_Beneficiary_Address] [varchar](50) NULL,
	[External_Final_Beneficiary_IsFI] [varchar](5) NULL,
	[External_Final_Beneficiary_Delivery_Code] [varchar](50) NULL,
	[External_Ordering_Institution_Name] [varchar](50) NULL,
	[External_Ordering_Institution_Account_Number] [varchar](50) NULL,
	[External_Ordering_Institution_BIC_Code] [varchar](50) NULL,
	[External_Ordering_Institution_Address] [varchar](50) NULL,
	[External_Ordering_Institution_IsFI] [varchar](5) NULL,
	[External_Ordering_Institution_Delivery_Code] [varchar](50) NULL,
	[Send_Flag] [varchar](1) NULL,
	[EntryDateTime] [datetime] NULL,
	[SentDateTime] [datetime] NULL,
	[ACK_NACK] [varchar](250) NULL,
	[ACK_NACK_DateTime] [datetime] NULL,
	[Settled_MsgRcvd] [varchar](1) NULL,
	[Settled_DateTime] [datetime] NULL,
	[Settlement_ReferenceString] [varchar](50) NULL,
	[CustidialAmount] [numeric](20, 0) NULL,
	[CustodialSwiftOriginal] [text] NULL,
	[SwiftMessage] [varchar](500) NULL,
	[Cancelflag] [varchar](1) NULL,
	[CancelDateTime] [datetime] NULL,
	[CancelAckNack] [varchar](250) NULL,
	[CancelAckNackDateTime] [datetime] NULL,
	[ApproverID] [numeric](10, 0) NULL,
	[ApproveFlag] [varchar](1) NULL,
	[ReviewFlag] [varchar](1) NULL,
	[ApproveDateTime] [datetime] NULL,
	[WiringInstructionsLinkId] [numeric](10, 0) NULL,
	[SettleUserNotification] [varchar](1) NULL,
PRIMARY KEY CLUSTERED 
(
	[SwiftTransferRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

